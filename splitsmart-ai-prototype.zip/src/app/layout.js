import "./globals.css";

export const metadata = {
  title: "SplitSmart AI",
  description: "A trust layer for shared money — verify expenses, don't just calculate them.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
