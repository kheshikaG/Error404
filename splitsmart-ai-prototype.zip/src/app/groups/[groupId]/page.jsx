import Link from "next/link";
import { notFound } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { Card, PrimaryButton, SecondaryButton, AvatarStack, EmptyState } from "@/components/ui";
import { BalanceSummary, ExpenseCard } from "@/components/split-components";
import { getGroupDetail, computeGroupBalances, getActivityLog, CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";
import { formatMoney } from "@/lib/money";

export default async function GroupDashboardPage({ params }) {
  const { groupId } = await params;
  const group = getGroupDetail(groupId);
  if (!group) notFound();

  const { balances } = computeGroupBalances(groupId);
  const myBalance = balances.find((b) => b.userId === CURRENT_USER_ID)?.net ?? 0;
  const totalSpend = group.expenses
    .filter((e) => e.status === "confirmed" || e.status === "settled")
    .reduce((s, e) => s + e.total, 0);
  const pendingCount = group.expenses.filter((e) => e.status === "pending_approval").length;
  const currency = group.expenses[0]?.currency ?? "MUR";
  const recentActivity = getActivityLog(groupId).slice(0, 3);

  return (
    <AppShell user={MOCK_USERS[CURRENT_USER_ID]} title={group.name} backHref="/groups">
      <div className="mb-4 flex items-center justify-between">
        <AvatarStack names={group.members.map((m) => m.name)} />
        <Link href={`/groups/${groupId}/invite`}>
          <SecondaryButton className="px-3 py-1.5 text-xs">+ Invite</SecondaryButton>
        </Link>
      </div>

      <Card className="mb-4">
        <p className="text-xs text-[var(--muted)]">
          {formatMoney(totalSpend, currency)} spent
          {pendingCount > 0 && ` · ${pendingCount} pending approval${pendingCount > 1 ? "s" : ""}`}
        </p>
        <div className="mt-1.5">
          <BalanceSummary netMinor={myBalance} currency={currency} size="lg" />
        </div>
        <Link href={`/groups/${groupId}/settle`}>
          <PrimaryButton className="mt-3 w-full py-2.5">Settle up</PrimaryButton>
        </Link>
      </Card>

      <Link href={`/groups/${groupId}/expense/new`}>
        <PrimaryButton className="mb-4 w-full py-3">+ Add expense</PrimaryButton>
      </Link>

      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-[var(--muted)]">Recent expenses</h2>
        <Link href={`/groups/${groupId}/activity`} className="text-xs font-semibold text-[var(--accent)]">
          Full activity log →
        </Link>
      </div>

      {group.expenses.length === 0 ? (
        <EmptyState
          icon="🧾"
          title="No expenses yet"
          description="Scan your first receipt to get started."
          action={
            <Link href={`/groups/${groupId}/expense/new`}>
              <PrimaryButton className="px-5 py-2.5">Add an expense</PrimaryButton>
            </Link>
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {group.expenses.map((e) => (
            <ExpenseCard
              key={e.id}
              expense={e}
              payerName={group.members.find((m) => m.id === e.paidBy)?.name ?? MOCK_USERS[e.paidBy]?.name}
              href={`/groups/${groupId}/expense/${e.id}`}
            />
          ))}
        </div>
      )}

      {recentActivity.length > 0 && (
        <div className="mt-5">
          <h2 className="mb-2 text-sm font-semibold text-[var(--muted)]">Activity preview</h2>
          <Card className="divide-y divide-[var(--border)] p-0">
            {recentActivity.map((a) => (
              <p key={a.id} className="px-4 py-2.5 text-xs text-[var(--muted)]">
                {a.text}
              </p>
            ))}
          </Card>
        </div>
      )}
    </AppShell>
  );
}
