"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { Card, Avatar } from "@/components/ui";
import { SettlementConfirmModal } from "@/components/split-components";
import { getSettlementPlan, getGroupDetail, CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";
import { formatMoney } from "@/lib/money";

export default function SettleUpPage() {
  const { groupId } = useParams();
  const you = MOCK_USERS[CURRENT_USER_ID];
  const group = getGroupDetail(groupId);
  const currency = group.expenses[0]?.currency ?? "MUR";
  const [plan, setPlan] = useState(() => getSettlementPlan(groupId));
  const [activeTxn, setActiveTxn] = useState(null);

  function markPaid(t) {
    setActiveTxn({ ...t, currency });
  }

  function onConfirmed(t) {
    // Real build: POST /api/groups/:id/settlements, then re-fetch balances.
    // Here we optimistically remove the settled transaction from the plan
    // so the "everyone's settled" empty state is reachable in the demo.
    setPlan((prev) => prev.filter((x) => !(x.from === t.from && x.to === t.to)));
  }

  return (
    <AppShell user={you} title="Settle up" backHref={`/groups/${groupId}`}>
      <h3 className="mb-2 text-sm font-semibold text-[var(--muted)]">Optimized settle-up plan</h3>
      <p className="mb-4 text-xs text-[var(--muted)]">
        Reduced to the minimum number of transactions to fully settle the group — not every pairwise debt.
      </p>

      {plan.length === 0 ? (
        <Card className="settled-pop py-8 text-center">
          <div className="text-3xl">✅</div>
          <p className="mt-2 font-semibold">Everyone&apos;s settled up</p>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {plan.map((t, i) => (
            <Card key={i} className="flex items-center gap-3 py-3">
              <Avatar name={t.fromName} size={30} />
              <div className="flex-1 text-sm">
                <strong>{t.fromName}</strong> pays <strong>{t.toName}</strong>
                {t.from === CURRENT_USER_ID && (
                  <p className="text-xs text-[var(--muted)]">Covers {countExpensesFor(group, t.from, t.to)} shared expense(s)</p>
                )}
              </div>
              <span className="font-semibold">{formatMoney(t.amount, currency)}</span>
              {t.from === CURRENT_USER_ID && (
                <button
                  onClick={() => markPaid(t)}
                  className="btn-secondary rounded-xl px-3 py-1.5 text-xs font-semibold"
                >
                  Mark paid
                </button>
              )}
            </Card>
          ))}
        </div>
      )}

      <SettlementConfirmModal
        open={!!activeTxn}
        transaction={activeTxn}
        onClose={() => setActiveTxn(null)}
        onConfirmCash={onConfirmed}
        onUploadProof={onConfirmed}
      />
    </AppShell>
  );
}

// Rough "covers N expenses" hint for the settle screen — counts confirmed
// expenses paid by `to` that `from` participated in.
function countExpensesFor(group, from, to) {
  return group.expenses.filter((e) => e.paidBy === to && e.items.some((it) => it.participantUserIds.includes(from))).length;
}
