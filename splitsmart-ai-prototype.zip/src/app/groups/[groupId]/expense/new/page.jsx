import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui";
import { CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";

const TILES = [
  { key: "receipt", icon: "📷", label: "Scan receipt", hint: "AI reads the items for you" },
  { key: "text", icon: "💬", label: "Type it out", hint: "\"I paid 500 for lunch, split with Sam\"" },
  { key: "proof", icon: "🧾", label: "Upload payment proof", hint: "Lost the receipt? Use your bank proof" },
  { key: "manual", icon: "✏️", label: "Manual entry", hint: "Needs group approval to count" },
];

export default async function AddExpenseEntryPage({ params }) {
  const { groupId } = await params;
  return (
    <AppShell user={MOCK_USERS[CURRENT_USER_ID]} title="Add an expense" backHref={`/groups/${groupId}`}>
      <p className="mb-4 text-sm text-[var(--muted)]">How was this expense paid for?</p>
      <div className="grid grid-cols-2 gap-3">
        {TILES.map((t) => (
          <Link
            key={t.key}
            href={
              t.key === "proof"
                ? `/groups/${groupId}/expense/new/manual?sourceType=bank_proof`
                : `/groups/${groupId}/expense/new/${t.key}`
            }
          >
            <Card className="flex h-full flex-col items-center gap-1.5 py-6 text-center transition hover:border-[var(--accent)] hover:shadow-md">
              <span className="text-3xl">{t.icon}</span>
              <span className="text-sm font-semibold">{t.label}</span>
              <span className="text-xs text-[var(--muted)]">{t.hint}</span>
            </Card>
          </Link>
        ))}
      </div>
    </AppShell>
  );
}
