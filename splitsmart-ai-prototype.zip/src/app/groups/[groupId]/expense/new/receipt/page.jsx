"use client";

import { useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { Card, PrimaryButton, SecondaryButton, Skeleton } from "@/components/ui";
import { SplitEditor } from "@/components/split-components";
import { getGroupDetail, CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";
import { MOCK_AI_RECEIPT_SCAN, MOCK_AI_RECEIPT_SCAN_MISMATCH } from "@/lib/mock-data";

let idCounter = 0;
function withIds(rawItems) {
  return rawItems.map((it) => ({ ...it, id: `mock-item-${idCounter++}`, participantUserIds: [] }));
}

// Demo mode: standing in for a real Claude-vision OCR call
// (src/lib/ai-llm.js / ocr.js in the full build). Picking the file just
// selects between two realistic canned AI outputs — one clean, one with a
// mismatch — so the reconciliation-warning UI can be demonstrated reliably.
// The review UI itself (SplitEditor) is real and works with either shape.
export default function ReceiptScanPage() {
  const { groupId } = useParams();
  const router = useRouter();
  const group = getGroupDetail(groupId);
  const you = MOCK_USERS[CURRENT_USER_ID];

  const [stage, setStage] = useState("upload"); // upload | scanning | review
  const [parsed, setParsed] = useState(null);
  const [items, setItems] = useState([]);
  const [paidBy, setPaidBy] = useState(CURRENT_USER_ID);
  const fileInputRef = useRef(null);

  function onFileSelected(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setStage("scanning");
    // Alternate between the clean and mismatched mock scan so both paths are
    // reachable from the same button during a demo.
    const mock = idCounter % 2 === 0 ? MOCK_AI_RECEIPT_SCAN_MISMATCH : MOCK_AI_RECEIPT_SCAN;
    setTimeout(() => {
      setParsed(mock);
      setItems(withIds(mock.items));
      setStage("review");
    }, 1400);
  }

  const subtotal = items.reduce((s, it) => s + it.price, 0);
  const total = subtotal + (parsed?.tax ?? 0) + (parsed?.service_charge ?? 0);

  function confirmAndSplit() {
    // In the full build this POSTs to /api/groups/:id/expenses/create.
    // For this prototype, land back on the group screen — the mock
    // service's existing expense list already demonstrates the resulting
    // states (confirmed / pending approval / mismatch flagged).
    router.push(`/groups/${groupId}`);
  }

  return (
    <AppShell user={you} title="Scan receipt" backHref={`/groups/${groupId}`}>
      {stage === "upload" && (
        <Card className="flex flex-col items-center gap-4 py-12 text-center">
          <span className="text-4xl">📷</span>
          <p className="text-sm text-[var(--muted)]">Take a photo of the receipt, or upload one from your gallery.</p>
          <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFileSelected} />
          <PrimaryButton onClick={() => fileInputRef.current?.click()} className="px-6 py-3">
            Choose photo
          </PrimaryButton>
        </Card>
      )}

      {stage === "scanning" && (
        <Card className="flex flex-col items-center gap-4 py-12 text-center">
          <Skeleton className="h-32 w-full max-w-[220px]" />
          <Skeleton className="h-4 w-40" />
          <p className="text-sm text-[var(--muted)]">Reading your receipt…</p>
        </Card>
      )}

      {stage === "review" && parsed && (
        <div className="flex flex-col gap-4">
          <Card className="p-3.5">
            <p className="text-xs text-[var(--muted)]">AI read this receipt as</p>
            <p className="font-semibold">
              {parsed.merchant} · {parsed.date}
            </p>
          </Card>

          <div>
            <span className="mb-1.5 block text-sm font-medium text-[var(--muted)]">Who paid?</span>
            <select className="input-field w-full px-3.5 py-2.5 text-sm" value={paidBy} onChange={(e) => setPaidBy(e.target.value)}>
              {group.members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <SplitEditor
            items={items}
            members={group.members}
            onChangeItems={setItems}
            currency={parsed.currency}
            tax={parsed.tax}
            serviceCharge={parsed.service_charge}
            declaredTotal={parsed.total}
          />

          <button
            onClick={() => setItems((prev) => [...prev, { id: `mock-item-${idCounter++}`, name: "", price: 0, participantUserIds: group.members.map((m) => m.id) }])}
            className="rounded-xl border border-dashed border-[var(--border)] py-2.5 text-sm font-medium text-[var(--accent)]"
          >
            + Add item (e.g. a tip not on the receipt)
          </button>

          <PrimaryButton onClick={confirmAndSplit} className="py-3">
            Confirm and split
          </PrimaryButton>
          <SecondaryButton onClick={() => setStage("upload")} className="py-2.5">
            Start over
          </SecondaryButton>
        </div>
      )}
    </AppShell>
  );
}
