"use client";

import { useState } from "react";
import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { Card, PrimaryButton, SecondaryButton, TextField } from "@/components/ui";
import { CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";

const TEMPLATES = [
  { id: "trip", icon: "✈️", label: "Trip", hint: "Settle up at the end" },
  { id: "roommates", icon: "🏠", label: "Roommates", hint: "Recurring monthly bills" },
  { id: "recurring", icon: "🔁", label: "Recurring bills", hint: "Subscriptions & utilities" },
  { id: "event", icon: "🎉", label: "One-off event", hint: "A single shared cost" },
  { id: "custom", icon: "📋", label: "Custom", hint: "Start from scratch" },
];

// Demo mode: no real group is persisted — this shows the full create + invite
// flow with a generated-looking invite code/link/QR, then returns to the
// dashboard. When Supabase is wired in, `onSubmit` becomes a real INSERT and
// the invite code becomes a real one instead of a client-generated string.
export default function NewGroupPage() {
  const you = MOCK_USERS[CURRENT_USER_ID];
  const [step, setStep] = useState("form"); // "form" | "invite"
  const [name, setName] = useState("");
  const [template, setTemplate] = useState("trip");
  const [approvalRule, setApprovalRule] = useState("quorum");
  const [inviteCode] = useState(() => Math.random().toString(36).slice(2, 8).toUpperCase());

  function onSubmit(e) {
    e.preventDefault();
    setStep("invite");
  }

  if (step === "invite") {
    const inviteLink = `splitsmart.app/join/${inviteCode}`;
    return (
      <AppShell user={you} title="Invite your group" backHref="/groups/new">
        <Card className="flex flex-col items-center gap-4 p-6 text-center">
          <div className="text-3xl">🎉</div>
          <div>
            <p className="text-lg font-bold">&quot;{name || "New group"}&quot; is ready</p>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Share this link or QR code so the group can join. New members sync in automatically.
            </p>
          </div>

          <div
            className="flex h-40 w-40 items-center justify-center rounded-xl border-2 border-dashed text-xs text-[var(--muted)]"
            style={{ borderColor: "var(--border)" }}
            aria-label="QR code to join the group"
          >
            <svg viewBox="0 0 100 100" width="120" height="120" aria-hidden>
              {Array.from({ length: 100 }).map((_, i) => {
                const seed = (inviteCode.charCodeAt(i % inviteCode.length) * (i + 1)) % 7;
                if (seed > 3) return null;
                const x = (i % 10) * 10;
                const y = Math.floor(i / 10) * 10;
                return <rect key={i} x={x} y={y} width="10" height="10" fill="currentColor" />;
              })}
            </svg>
          </div>

          <div className="w-full rounded-xl bg-[var(--background)] px-3 py-2.5 font-mono text-sm">{inviteLink}</div>

          <div className="flex w-full gap-2">
            <SecondaryButton
              className="flex-1"
              onClick={() => navigator.clipboard?.writeText(`https://${inviteLink}`)}
            >
              Copy link
            </SecondaryButton>
            <Link href="/groups" className="flex-1">
              <PrimaryButton className="w-full">Done</PrimaryButton>
            </Link>
          </div>
        </Card>
      </AppShell>
    );
  }

  return (
    <AppShell user={you} title="New group" backHref="/groups">
      <form onSubmit={onSubmit} className="flex flex-col gap-5">
        <TextField label="Group name" placeholder="e.g. Goa Trip" required value={name} onChange={(e) => setName(e.target.value)} />

        <div>
          <span className="mb-2 block text-sm font-medium text-[var(--muted)]">Template</span>
          <div className="grid grid-cols-2 gap-2">
            {TEMPLATES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTemplate(t.id)}
                className={`card flex flex-col items-start gap-0.5 p-3 text-left transition ${
                  template === t.id ? "border-[var(--accent)] ring-1 ring-[var(--accent)]" : ""
                }`}
              >
                <span className="text-xl">{t.icon}</span>
                <span className="text-sm font-semibold">{t.label}</span>
                <span className="text-xs text-[var(--muted)]">{t.hint}</span>
              </button>
            ))}
          </div>
        </div>

        <Card>
          <span className="mb-2 block text-sm font-medium">
            When someone adds an expense with no receipt or proof, who needs to approve it?
          </span>
          <label className="mb-2 flex items-start gap-2 text-sm">
            <input type="radio" checked={approvalRule === "quorum"} onChange={() => setApprovalRule("quorum")} className="mt-1" />
            <span>
              <strong>Majority</strong> — more than half the group approves
            </span>
          </label>
          <label className="flex items-start gap-2 text-sm">
            <input type="radio" checked={approvalRule === "all"} onChange={() => setApprovalRule("all")} className="mt-1" />
            <span>
              <strong>Everyone</strong> — every member must approve
            </span>
          </label>
        </Card>

        <PrimaryButton type="submit" disabled={!name} className="py-3">
          Continue to invite
        </PrimaryButton>
      </form>
    </AppShell>
  );
}
