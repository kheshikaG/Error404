import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { Card, EmptyState, PrimaryButton, SecondaryButton, AvatarStack } from "@/components/ui";
import { BalanceSummary } from "@/components/split-components";
import { listGroupsForCurrentUser, CURRENT_USER_ID, MOCK_USERS } from "@/lib/mock-service";
import { formatMoney } from "@/lib/money";

// Demo mode: served from mock data (see mock-service.js), no auth/network
// wiring required to browse the prototype. Swap for a real fetch when
// Supabase is connected — this component doesn't need to change shape.
export default function GroupsPage() {
  const groups = listGroupsForCurrentUser();
  const you = MOCK_USERS[CURRENT_USER_ID];

  return (
    <AppShell user={you} title="Your groups">
      <div className="mb-4 flex gap-2">
        <Link href="/groups/new" className="flex-1">
          <PrimaryButton className="w-full py-3">+ New group</PrimaryButton>
        </Link>
        <Link href="/groups/join" className="flex-1">
          <SecondaryButton className="w-full py-3">Join with code</SecondaryButton>
        </Link>
      </div>

      {groups.length === 0 ? (
        <EmptyState
          icon="👥"
          title="No groups yet"
          description="Create a group for a trip, your roommates, or recurring bills to start splitting expenses."
          action={
            <Link href="/groups/new">
              <PrimaryButton className="mt-1 px-5 py-2.5">Create your first group</PrimaryButton>
            </Link>
          }
        />
      ) : (
        <div className="flex flex-col gap-3">
          {groups.map((g) => (
            <Link key={g.id} href={`/groups/${g.id}`}>
              <Card className="transition hover:border-[var(--accent)]">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-semibold">{g.name}</h3>
                    <p className="mt-0.5 text-xs text-[var(--muted)]">
                      {g.expenseCount} expenses · {formatMoney(g.totalSpend, g.currency)} total
                    </p>
                  </div>
                  <AvatarStack names={g.members.map((m) => m.name)} />
                </div>
                <div className="mt-3 border-t border-[var(--border)] pt-3">
                  <BalanceSummary netMinor={g.yourBalance} currency={g.currency} />
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </AppShell>
  );
}
