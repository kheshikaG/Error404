import Link from "next/link";
import { Avatar } from "@/components/ui";

// Prototype has no auth — `user` is always the fixed demo user
// (CURRENT_USER_ID in mock-data.js). No logout button, since there's
// nothing to log out of yet.
export function AppShell({ user, title, backHref, children }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b border-[var(--border)] bg-[var(--surface)]/90 backdrop-blur">
        <div className="mx-auto flex max-w-xl items-center gap-3 px-4 py-3">
          {backHref ? (
            <Link
              href={backHref}
              aria-label="Back"
              className="flex h-8 w-8 items-center justify-center rounded-full text-lg text-[var(--muted)] hover:bg-[var(--background)]"
            >
              ←
            </Link>
          ) : (
            <Link href="/groups" className="flex h-8 w-8 items-center justify-center rounded-xl bg-[var(--accent)] text-sm font-bold text-white">
              S
            </Link>
          )}
          <h1 className="flex-1 truncate text-base font-semibold">{title}</h1>
          {user && <Avatar name={user.name} size={30} />}
        </div>
      </header>
      <main className="mx-auto max-w-xl px-4 py-5">{children}</main>
    </div>
  );
}
