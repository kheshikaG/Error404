export function Card({
  children,
  className = ""
}) {
  return <div className={`card p-5 ${className}`}>{children}</div>;
}
export function PrimaryButton({
  children,
  className = "",
  ...props
}) {
  return <button className={`btn-primary px-4 py-2.5 text-sm ${className}`} {...props}>
      {children}
    </button>;
}
export function SecondaryButton({
  children,
  className = "",
  ...props
}) {
  return <button className={`btn-secondary px-4 py-2.5 text-sm ${className}`} {...props}>
      {children}
    </button>;
}
export function TextField({
  label,
  error,
  className = "",
  ...props
}) {
  return <label className="block">
      {label && <span className="mb-1.5 block text-sm font-medium text-[var(--muted)]">{label}</span>}
      <input className={`input-field w-full px-3.5 py-2.5 text-sm ${className}`} {...props} />
      {error && <span className="mt-1 block text-xs text-[var(--status-disputed)]">{error}</span>}
    </label>;
}
// Every trust/evidence state the app can show for an expense or settlement.
// Per the design spec: never rely on color alone — icon + text label always
// travel together.
const STATUS_META = {
  confirmed: {
    label: "Confirmed",
    className: "badge-confirmed",
    icon: "✓"
  },
  pending_approval: {
    label: "Pending approval",
    className: "badge-pending",
    icon: "⏳"
  },
  pending_confirmation: {
    label: "Pending confirmation",
    className: "badge-waiting",
    icon: "👤"
  },
  disputed: {
    label: "Disputed",
    className: "badge-disputed",
    icon: "⚑"
  },
  settled: {
    label: "Settled",
    className: "badge-confirmed",
    icon: "✅"
  },
  // legacy alias kept so any older call sites don't break
  pending: {
    label: "Pending approval",
    className: "badge-pending",
    icon: "⏳"
  }
};
export function StatusBadge({
  status,
  className = ""
}) {
  const meta = STATUS_META[status] ?? STATUS_META.pending_approval;
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold ${meta.className} ${className}`}>
      <span aria-hidden>{meta.icon}</span>
      {meta.label}
    </span>;
}
export function Avatar({
  name,
  size = 32
}) {
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  // Deterministic color from the name so the same person always gets the
  // same avatar color across the app.
  const hue = Array.from(name).reduce((acc, c) => acc + c.charCodeAt(0), 0) % 360;
  return <div role="img" aria-label={name} title={name} style={{
    width: size,
    height: size,
    background: `hsl(${hue}, 65%, 45%)`,
    fontSize: size * 0.38
  }} className="flex shrink-0 items-center justify-center rounded-full font-semibold text-white">
      {initials}
    </div>;
}
export function AvatarStack({
  names,
  max = 4
}) {
  const shown = names.slice(0, max);
  const remaining = names.length - shown.length;
  return <div className="flex -space-x-2">
      {shown.map((n, i) => <div key={i} className="rounded-full ring-2 ring-[var(--surface)]">
          <Avatar name={n} size={28} />
        </div>)}
      {remaining > 0 && <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[var(--border)] text-xs font-semibold ring-2 ring-[var(--surface)]">
          +{remaining}
        </div>}
    </div>;
}
export function Skeleton({
  className = ""
}) {
  return <div className={`skeleton ${className}`} />;
}
export function EmptyState({
  icon,
  title,
  description,
  action
}) {
  return <div className="flex flex-col items-center gap-3 py-14 text-center">
      <div className="text-4xl" aria-hidden>
        {icon}
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="max-w-xs text-sm text-[var(--muted)]">{description}</p>
      {action}
    </div>;
}
