"use client";

import { useState } from "react";
import Link from "next/link";
import { Avatar, AvatarStack, Card, PrimaryButton, SecondaryButton, StatusBadge } from "@/components/ui";
import { formatMoney } from "@/lib/money";

// ---------------------------------------------------------------------------
// AvatarPicker — tap-to-toggle group members on/off per line item.
// ---------------------------------------------------------------------------
export function AvatarPicker({ members, selectedIds, onChange, size = 30 }) {
  function toggle(id) {
    if (selectedIds.includes(id)) {
      onChange(selectedIds.filter((x) => x !== id));
    } else {
      onChange([...selectedIds, id]);
    }
  }
  return (
    <div className="flex flex-wrap gap-1.5">
      {members.map((m) => {
        const active = selectedIds.includes(m.id);
        return (
          <button
            key={m.id}
            type="button"
            onClick={() => toggle(m.id)}
            aria-pressed={active}
            title={m.name}
            className={`relative rounded-full transition-all ${active ? "ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--surface)]" : "opacity-40 hover:opacity-70"}`}
          >
            <Avatar name={m.name} size={size} />
          </button>
        );
      })}
    </div>
  );
}

// ---------------------------------------------------------------------------
// ApprovalMeter — progress bar, "2 of 3 approved"
// ---------------------------------------------------------------------------
export function ApprovalMeter({ received, needed }) {
  const pct = needed > 0 ? Math.min(100, Math.round((received / needed) * 100)) : 100;
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs font-medium text-[var(--muted)]">
        <span>Approval progress</span>
        <span>
          {received} of {needed} approved
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-[var(--border)]">
        <div
          className="h-full rounded-full bg-[var(--accent)] transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// BalanceSummary — the "you owe / you're owed" widget
// ---------------------------------------------------------------------------
export function BalanceSummary({ netMinor, currency = "MUR", size = "md" }) {
  const isSettled = netMinor === 0;
  const youAreOwed = netMinor > 0;
  const big = size === "lg";
  return (
    <div className={`flex items-center gap-3 ${big ? "py-2" : ""}`}>
      <div
        className={`flex ${big ? "h-14 w-14 text-2xl" : "h-10 w-10 text-lg"} shrink-0 items-center justify-center rounded-full font-bold`}
        style={{
          background: isSettled ? "var(--status-confirmed-bg)" : youAreOwed ? "var(--status-confirmed-bg)" : "var(--status-pending-bg)",
          color: isSettled ? "var(--status-confirmed)" : youAreOwed ? "var(--status-confirmed)" : "var(--status-pending)",
        }}
        aria-hidden
      >
        {isSettled ? "✓" : youAreOwed ? "↓" : "↑"}
      </div>
      <div>
        <div className={`${big ? "text-2xl" : "text-base"} font-bold`}>
          {isSettled ? "Settled up" : formatMoney(Math.abs(netMinor), currency)}
        </div>
        <div className="text-xs font-medium text-[var(--muted)]">
          {isSettled ? "You're all square in this group" : youAreOwed ? "You are owed" : "You owe"}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// ExpenseCard — visually distinct states for Confirmed / Pending / Disputed
// ---------------------------------------------------------------------------
export function ExpenseCard({ expense, payerName, href }) {
  const Wrapper = href ? Link : "div";
  const wrapperProps = href ? { href } : {};
  return (
    <Wrapper
      {...wrapperProps}
      className="card flex items-center justify-between gap-3 p-4 transition-shadow hover:shadow-md"
    >
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <p className="truncate font-semibold">{expense.merchant}</p>
          <StatusBadge status={expense.status} />
        </div>
        <p className="mt-0.5 text-xs text-[var(--muted)]">
          {expense.date} · Paid by {payerName ?? expense.paidBy} ·{" "}
          {expense.sourceType === "receipt" ? "Receipt" : expense.sourceType === "manual" ? "Manual entry" : expense.sourceType}
        </p>
        {expense.status === "pending_approval" && (
          <div className="mt-2 max-w-[220px]">
            <ApprovalMeter received={expense.approvals.received} needed={expense.approvals.needed} />
          </div>
        )}
      </div>
      <p className="shrink-0 text-right font-bold">{formatMoney(expense.total, expense.currency)}</p>
    </Wrapper>
  );
}

// ---------------------------------------------------------------------------
// SplitEditor — the core review UI for adjusting AI-proposed splits
// ---------------------------------------------------------------------------
export function SplitEditor({ items, members, onChangeItems, currency = "INR", tax = 0, serviceCharge = 0, declaredTotal }) {
  function updateParticipants(itemId, participantUserIds) {
    onChangeItems(items.map((it) => (it.id === itemId ? { ...it, participantUserIds } : it)));
  }

  const itemsSubtotal = items.reduce((s, it) => s + it.price, 0);
  const allocated = items.reduce((s, it) => (it.participantUserIds.length > 0 ? s + it.price : s), 0);
  const remaining = itemsSubtotal - allocated;
  const computedTotal = itemsSubtotal + tax + serviceCharge;
  const mismatch = declaredTotal != null && computedTotal !== declaredTotal;

  return (
    <div className="space-y-4">
      {mismatch && (
        <div
          role="alert"
          className="flex items-start gap-2 rounded-xl border p-3 text-sm"
          style={{ borderColor: "var(--status-disputed)", background: "var(--status-disputed-bg)", color: "var(--status-disputed)" }}
        >
          <span aria-hidden>⚠️</span>
          <span>
            <strong>Totals don&apos;t reconcile.</strong> Items + tax + service = {formatMoney(computedTotal, currency)}, but the
            receipt says {formatMoney(declaredTotal, currency)} (difference of {formatMoney(Math.abs(declaredTotal - computedTotal), currency)}).
            Double-check the amounts below before confirming.
          </span>
        </div>
      )}

      <div className="space-y-3">
        {items.map((item) => (
          <Card key={item.id} className="p-3.5">
            <div className="flex items-center justify-between gap-3">
              <p className="font-medium">{item.name}</p>
              <p className="font-semibold">{formatMoney(item.price, currency)}</p>
            </div>
            <div className="mt-2.5">
              <AvatarPicker
                members={members}
                selectedIds={item.participantUserIds}
                onChange={(ids) => updateParticipants(item.id, ids)}
              />
              {item.participantUserIds.length === 0 && (
                <p className="mt-1 text-xs text-[var(--status-pending)]">Tap an avatar to assign who&apos;s in on this item.</p>
              )}
            </div>
          </Card>
        ))}
      </div>

      <Card className="flex items-center justify-between p-3.5 text-sm">
        <span className="text-[var(--muted)]">Allocated vs. remaining</span>
        <span className={`font-semibold ${remaining !== 0 ? "text-[var(--status-pending)]" : "text-[var(--status-confirmed)]"}`}>
          {formatMoney(allocated, currency)} allocated · {formatMoney(remaining, currency)} remaining
        </span>
      </Card>

      <div className="space-y-1 text-sm text-[var(--muted)]">
        <div className="flex justify-between">
          <span>Items subtotal</span>
          <span>{formatMoney(itemsSubtotal, currency)}</span>
        </div>
        <div className="flex justify-between">
          <span>Tax</span>
          <span>{formatMoney(tax, currency)}</span>
        </div>
        <div className="flex justify-between">
          <span>Service charge / tip</span>
          <span>{formatMoney(serviceCharge, currency)}</span>
        </div>
        <div className="flex justify-between border-t border-[var(--border)] pt-1 font-semibold text-[var(--foreground)]">
          <span>Total</span>
          <span>{formatMoney(declaredTotal ?? computedTotal, currency)}</span>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// SettlementConfirmModal — bank-proof vs cash-confirmation branch
// ---------------------------------------------------------------------------
export function SettlementConfirmModal({ open, onClose, transaction, onConfirmCash, onUploadProof }) {
  const [method, setMethod] = useState(null); // "cash" | "bank"
  const [justSettled, setJustSettled] = useState(false);

  if (!open) return null;

  if (justSettled) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
        <Card className="settled-pop w-full max-w-sm p-6 text-center">
          <div className="text-4xl">✅</div>
          <p className="mt-2 text-lg font-bold">Settled!</p>
          <p className="mt-1 text-sm text-[var(--muted)]">
            {transaction.fromName} → {transaction.toName} · {formatMoney(transaction.amount, transaction.currency ?? "MUR")}
          </p>
          <PrimaryButton className="mt-4 w-full" onClick={onClose}>
            Done
          </PrimaryButton>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <Card className="w-full max-w-sm p-6">
        <p className="text-lg font-bold">Confirm settlement</p>
        <p className="mt-1 text-sm text-[var(--muted)]">
          {transaction.fromName} pays {transaction.toName} {formatMoney(transaction.amount, transaction.currency ?? "MUR")}
        </p>

        {!method && (
          <div className="mt-4 space-y-2">
            <SecondaryButton className="w-full" onClick={() => setMethod("cash")}>
              💵 Paid in cash
            </SecondaryButton>
            <SecondaryButton className="w-full" onClick={() => setMethod("bank")}>
              🏦 Paid via bank transfer
            </SecondaryButton>
          </div>
        )}

        {method === "cash" && (
          <div className="mt-4 rounded-xl p-3 text-sm" style={{ background: "var(--status-waiting-bg)", color: "var(--status-waiting)" }}>
            A confirmation request will be sent to <strong>{transaction.toName}</strong> — this only counts as settled once they
            confirm they received it, not just on your word.
          </div>
        )}
        {method === "bank" && (
          <div className="mt-4 rounded-xl p-3 text-sm" style={{ background: "var(--status-confirmed-bg)", color: "var(--status-confirmed)" }}>
            Upload your bank proof of payment — once it reconciles with the amount, this is auto-confirmed.
          </div>
        )}

        <div className="mt-5 flex gap-2">
          <SecondaryButton className="flex-1" onClick={onClose}>
            Cancel
          </SecondaryButton>
          {method && (
            <PrimaryButton
              className="flex-1"
              onClick={() => {
                setJustSettled(true);
                if (method === "cash") onConfirmCash?.(transaction);
                else onUploadProof?.(transaction);
              }}
            >
              {method === "cash" ? "Send for confirmation" : "Upload & confirm"}
            </PrimaryButton>
          )}
        </div>
      </Card>
    </div>
  );
}
