import { Router } from 'express';
import { all, run } from '../database/db.js';
import { id, z, assert } from '../middleware/validation.js';
export const activityRoutes = Router();
activityRoutes.get('/notifications', async (req, res) => {
  const offset = z.coerce.number().int().min(0).default(0).parse(req.query.offset);
  res.json(await all('SELECT n.*,p.status AS payment_status,p.receiver_id,p.sender_id FROM notifications n LEFT JOIN cash_payments p ON p.id=n.payment_id WHERE n.user_id=? ORDER BY n.id DESC LIMIT 50 OFFSET ?', req.user.id, offset));
});
activityRoutes.post('/notifications/:id/read', async (req, res) => {
  const result = await run('UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?', id.parse(req.params.id), req.user.id);
  assert(result.changes, 'Notification not found.', 404);
  res.json({
    ok: true
  });
});
activityRoutes.get('/audit-logs', async (req, res) => {
  const offset = z.coerce.number().int().min(0).default(0).parse(req.query.offset);
  res.json(await all('SELECT a.*,u.name FROM audit_logs a JOIN users u ON u.id=a.user_id WHERE (a.group_id IS NULL AND a.user_id=?) OR a.group_id IN(SELECT group_id FROM group_members WHERE user_id=?) ORDER BY a.id DESC LIMIT 50 OFFSET ?', req.user.id, req.user.id, offset));
});
