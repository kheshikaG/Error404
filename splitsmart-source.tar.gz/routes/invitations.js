import { Router } from 'express';
import { randomBytes, createHash } from 'node:crypto';
import { rateLimit } from 'express-rate-limit';
import { get, run, transaction, audit, notify } from '../database/db.js';
import { membership } from '../middleware/authorization.js';
import { z, assert } from '../middleware/validation.js';
export const invitationRoutes = Router();
const hash = t => createHash('sha256').update(t).digest('hex');
const tokenSchema = z.string().regex(/^[0-9a-f]{64}$/);
const limit = rateLimit({
  windowMs: 60000,
  limit: 20,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: {
    error: 'Please wait before trying another invitation.'
  }
});
invitationRoutes.post('/groups/:id/invitations', limit, async (req, res) => {
  const m = await membership(req.user.id, req.params.id, true),
    token = randomBytes(32).toString('hex'),
    expires = Date.now() + 7 * 86400000;
  await transaction(async () => {
    await run('INSERT INTO group_invitations(group_id,created_by,token_hash,expires_at) VALUES(?,?,?,?)', m.group_id, req.user.id, hash(token), expires);
    await audit(req.user.id, m.group_id, 'invitation_created', 'Single-use invitation; expires in seven days.');
  });
  res.status(201).json({
    url: process.env.APP_ORIGIN + '/#invite=' + token,
    expires_at: expires
  });
});
invitationRoutes.post('/invitations/inspect', limit, async (req, res) => {
  const token = tokenSchema.parse(req.body.token);
  const i = await get('SELECT i.*,g.name,g.currency FROM group_invitations i JOIN groups g ON g.id=i.group_id WHERE token_hash=? AND used_by IS NULL AND expires_at>? AND g.archived=0', hash(token), Date.now());
  assert(i, 'This invitation is invalid, expired, or already used.', 404);
  res.json({
    name: i.name,
    currency: i.currency,
    expires_at: i.expires_at
  });
});
invitationRoutes.post('/invitations/accept', limit, async (req, res) => {
  const token = tokenSchema.parse(req.body.token);
  const gid = await transaction(async () => {
    const i = await get('SELECT i.*,g.name FROM group_invitations i JOIN groups g ON g.id=i.group_id WHERE token_hash=? AND used_by IS NULL AND expires_at>? AND g.archived=0', hash(token), Date.now());
    assert(i, 'This invitation is invalid, expired, or already used.', 404);
    assert(!(await get('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?', i.group_id, req.user.id)), 'You already belong to this group.');
    await run('INSERT INTO group_members VALUES(?,?,?)', i.group_id, req.user.id, 'member');
    await run('UPDATE group_invitations SET used_by=? WHERE id=?', req.user.id, i.id);
    await audit(req.user.id, i.group_id, 'invitation_accepted');
    await notify(i.created_by, i.group_id, `${req.user.name} joined ${i.name}.`);
    return i.group_id;
  });
  res.json({
    group_id: gid
  });
});
