import { Router } from 'express';
import { all, get, run, transaction, audit, notify } from '../database/db.js';
import { membership } from '../middleware/authorization.js';
import { z, id, currency, assert } from '../middleware/validation.js';
import { balances, settlements } from '../services/finance.js';
export const groupRoutes = Router();
groupRoutes.get('/groups', async (req, res) => res.json(await Promise.all((await all('SELECT g.*,m.role,(SELECT count(*) FROM group_members WHERE group_id=g.id) AS member_count FROM groups g JOIN group_members m ON m.group_id=g.id WHERE m.user_id=? AND g.archived=0 ORDER BY g.id', req.user.id)).map(async g => ({
  ...g,
  balance: await balances(g.id)
})))));
groupRoutes.post('/groups', async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(1).max(100),
    currency
  }).parse(req.body);
  const gid = await transaction(async () => {
    const gid = Number((await run('INSERT INTO groups(name,currency,created_by) VALUES(?,?,?)', d.name, d.currency, req.user.id)).lastInsertRowid);
    await run('INSERT INTO group_members VALUES(?,?,?)', gid, req.user.id, 'owner');
    await audit(req.user.id, gid, 'group_created', d.name);
    return gid;
  });
  res.status(201).json({
    id: gid
  });
});
groupRoutes.get('/groups/:id', async (req, res) => {
  await membership(req.user.id, req.params.id);
  res.json({
    ...(await get('SELECT * FROM groups WHERE id=?', Number(req.params.id))),
    members: await all('SELECT u.id,u.name,u.email,m.role FROM users u JOIN group_members m ON m.user_id=u.id WHERE m.group_id=?', Number(req.params.id))
  });
});
groupRoutes.put('/groups/:id', async (req, res) => {
  await membership(req.user.id, req.params.id, true);
  const name = z.string().trim().min(1).max(100).parse(req.body.name);
  await run('UPDATE groups SET name=? WHERE id=?', name, Number(req.params.id));
  await audit(req.user.id, Number(req.params.id), 'group_renamed', name);
  res.json({
    ok: true
  });
});
groupRoutes.delete('/groups/:id', async (req, res) => {
  const m = await membership(req.user.id, req.params.id, true);
  assert(m.role === 'owner', 'Only the owner can delete a group.', 403);
  assert((await balances(m.group_id)).members.every(u => u.net === 0), 'Settle all balances first.');
  assert(!(await get('SELECT id FROM cash_payments WHERE group_id=? AND status=?', m.group_id, 'pending')), 'Resolve pending payments first.');
  await transaction(async () => {
    await run('UPDATE groups SET archived=1 WHERE id=?', m.group_id);
    await audit(req.user.id, m.group_id, 'group_deleted', 'Group archived; audit history retained.');
  });
  res.json({
    ok: true
  });
});
groupRoutes.post('/groups/:id/members', async (req, res) => {
  const m = await membership(req.user.id, req.params.id, true);
  const email = z.email().parse(req.body.email);
  const u = await get('SELECT id FROM users WHERE email=? AND status=?', email, 'active');
  assert(u, 'Ask this person to register first, then add their email.');
  assert(!(await get('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?', m.group_id, u.id)), 'This person is already a member.');
  await transaction(async () => {
    await run('INSERT INTO group_members VALUES(?,?,?)', m.group_id, u.id, 'member');
    await notify(u.id, m.group_id, `You were added to ${m.name}.`);
    await audit(req.user.id, m.group_id, 'member_added', email);
  });
  res.status(201).json({
    ok: true
  });
});
groupRoutes.put('/groups/:id/members/:uid', async (req, res) => {
  const m = await membership(req.user.id, req.params.id, true);
  assert(m.role === 'owner', 'Only the owner can assign roles.', 403);
  const uid = id.parse(req.params.uid),
    role = z.enum(['admin', 'member']).parse(req.body.role);
  assert(uid !== req.user.id, 'The owner role cannot be changed here.');
  await membership(uid, m.group_id);
  await run('UPDATE group_members SET role=? WHERE group_id=? AND user_id=?', role, m.group_id, uid);
  await audit(req.user.id, m.group_id, 'role_updated', `${uid}: ${role}`);
  res.json({
    ok: true
  });
});
groupRoutes.delete('/groups/:id/members/:uid', async (req, res) => {
  const uid = id.parse(req.params.uid),
    m = await membership(req.user.id, req.params.id, uid !== req.user.id);
  const target = await membership(uid, m.group_id);
  assert(target.role !== 'owner', 'The owner must delete the settled group instead.');
  assert(uid === req.user.id || m.role === 'owner' || target.role === 'member', 'Only the owner can remove an admin.', 403);
  assert(!(await get('SELECT e.id FROM expenses e LEFT JOIN expense_shares s ON s.expense_id=e.id WHERE e.group_id=? AND (e.payer_id=? OR s.user_id=?) AND e.status=?', m.group_id, uid, uid, 'active')) && !(await get('SELECT id FROM cash_payments WHERE group_id=? AND (sender_id=? OR receiver_id=?)', m.group_id, uid, uid)), 'Members with ledger history remain in the group to preserve balances. Archive the settled group instead.');
  await transaction(async () => {
    await run('DELETE FROM group_members WHERE group_id=? AND user_id=?', m.group_id, uid);
    await audit(req.user.id, m.group_id, 'member_removed', String(uid));
  });
  res.json({
    ok: true
  });
});
groupRoutes.get('/groups/:id/balances', async (req, res) => {
  await membership(req.user.id, req.params.id);
  const b = await balances(Number(req.params.id));
  res.json({
    ...b,
    settlements: settlements(b.members)
  });
});
