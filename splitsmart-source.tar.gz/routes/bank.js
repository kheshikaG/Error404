import { Router } from 'express';
import { createHash } from 'node:crypto';
import { rateLimit } from 'express-rate-limit';
import { all, get, run, batch, transaction, audit, notify } from '../database/db.js';
import { z, id, assert } from '../middleware/validation.js';
import { membership } from '../middleware/authorization.js';
import { parseStatement } from '../services/statements.js';
import { matchBankTransaction } from '../services/finance.js';
export const bankRoutes = Router();
bankRoutes.use('/bank', rateLimit({
  windowMs: 60000,
  limit: 30,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: {
    error: 'Please wait a minute before trying the bank connection again.'
  }
}));
bankRoutes.post('/bank/import/preview', (req, res) => {
  const rows = parseStatement(req.body.csv);
  res.json({
    transactions: rows
  });
});
bankRoutes.post('/bank/import', async (req, res) => {
  assert(req.body.confirmed === true, 'Review the statement before importing.');
  const rows = parseStatement(req.body.csv),
    digest = createHash('sha256').update(JSON.stringify(rows)).digest('hex');
  assert(!(await get('SELECT id FROM bank_imports WHERE user_id=? AND content_hash=?', req.user.id, digest)), 'This statement has already been imported.', 409);
  await transaction(async () => {
    let connection = await get('SELECT id FROM bank_connections WHERE user_id=? AND status=?', req.user.id, 'connected');
    if (!connection) connection = {
      id: Number((await run('INSERT INTO bank_connections(user_id,provider,status) VALUES(?,?,?)', req.user.id, 'Statement import', 'connected')).lastInsertRowid)
    };
    await batch(rows.map(row=>({sql:'INSERT INTO bank_transactions(connection_id,merchant,amount,currency,transaction_date) VALUES(?,?,?,?,?)',args:[connection.id,row.merchant,row.amount,row.currency,row.transaction_date]})));
    await run('INSERT INTO bank_imports(user_id,content_hash) VALUES(?,?)', req.user.id, digest);
    await audit(req.user.id, null, 'statement_imported', `${rows.length} user-provided transactions`);
  });
  res.status(201).json({
    count: rows.length
  });
});
bankRoutes.get('/bank/transactions', async (req, res) => {
  const connection = await get('SELECT id,provider,status,permission FROM bank_connections WHERE user_id=? AND status=?', req.user.id, 'connected');
  if (!connection) return res.json({
    connection: null,
    transactions: []
  });
  const expenses = await all('SELECT e.* FROM expenses e JOIN group_members m ON m.group_id=e.group_id JOIN groups g ON g.id=e.group_id WHERE m.user_id=? AND e.payer_id=? AND e.status=? AND g.archived=0', req.user.id, req.user.id, 'active');
  const transactions = await all('SELECT t.*,tm.expense_id FROM bank_transactions t LEFT JOIN transaction_matches tm ON tm.transaction_id=t.id WHERE connection_id=?', connection.id);
  const matched = new Set((await all('SELECT expense_id FROM transaction_matches WHERE user_id=?', req.user.id)).map(m => m.expense_id));
  const dismissed = new Set((await all('SELECT transaction_id,expense_id FROM bank_dismissals WHERE user_id=?', req.user.id)).map(d => d.transaction_id + ':' + d.expense_id));
  for (const t of transactions) t.suggestions = t.expense_id ? [] : expenses.filter(e => !matched.has(e.id) && !dismissed.has(t.id + ':' + e.id)).map(e => ({
    ...e,
    score: matchBankTransaction(e, t)
  })).filter(e => e.score >= 0.65).sort((a, b) => b.score - a.score);
  res.json({
    connection,
    transactions
  });
});
bankRoutes.post('/bank/match', async (req, res) => {
  const d = z.object({
    transaction_id: id,
    expense_id: id
  }).parse(req.body);
  const t = await get('SELECT t.* FROM bank_transactions t JOIN bank_connections c ON c.id=t.connection_id WHERE t.id=? AND c.user_id=? AND c.status=?', d.transaction_id, req.user.id, 'connected');
  assert(t, 'Transaction not available.', 403);
  const e = await get('SELECT * FROM expenses WHERE id=? AND status=?', d.expense_id, 'active');
  assert(e, 'Expense not found.', 404);
  await membership(req.user.id, e.group_id);
  assert(e.payer_id === req.user.id, 'You can only match expenses you paid.', 403);
  assert(e.amount === Math.abs(t.amount) && e.currency === t.currency && t.amount < 0, 'Transaction amount or currency does not match.');
  assert(!(await get('SELECT id FROM transaction_matches WHERE transaction_id=? OR expense_id=?', t.id, e.id)), 'Already matched.', 409);
  await transaction(async () => {
    await run('INSERT INTO transaction_matches(transaction_id,expense_id,user_id) VALUES(?,?,?)', t.id, e.id, req.user.id);
    if (Math.abs(Date.parse(e.expense_date) - Date.parse(t.transaction_date)) > 3 * 86400000) await run('UPDATE expenses SET review_reason=? WHERE id=?', 'Bank transaction date differs by more than three days', e.id);
    await audit(req.user.id, e.group_id, 'transaction_matched', `${t.merchant}: ${e.description}`);
  });
  res.json({
    ok: true
  });
});
bankRoutes.post('/bank/dismiss', async (req, res) => {
  const d = z.object({
    transaction_id: id,
    expense_id: id
  }).parse(req.body);
  assert(await get('SELECT t.id FROM bank_transactions t JOIN bank_connections c ON c.id=t.connection_id WHERE t.id=? AND c.user_id=?', d.transaction_id, req.user.id), 'Transaction unavailable.', 403);
  const e = await get('SELECT group_id FROM expenses WHERE id=?', d.expense_id);
  assert(e, 'Expense unavailable.', 404);
  await membership(req.user.id, e.group_id);
  await run('INSERT OR IGNORE INTO bank_dismissals VALUES(?,?,?)', d.transaction_id, d.expense_id, req.user.id);
  res.json({
    ok: true
  });
});
bankRoutes.delete('/bank/matches/:eid', async (req, res) => {
  const eid = id.parse(req.params.eid);
  const m = await get('SELECT * FROM transaction_matches WHERE expense_id=? AND user_id=?', eid, req.user.id);
  assert(m, 'Match not available.', 403);
  const e = await get('SELECT group_id FROM expenses WHERE id=?', eid);
  await membership(req.user.id, e.group_id);
  await transaction(async () => {
    await run('DELETE FROM transaction_matches WHERE id=?', m.id);
    await audit(req.user.id, e.group_id, 'transaction_unmatched');
  });
  res.json({
    ok: true
  });
});
bankRoutes.post('/bank/disconnect', async (req, res) => {
  await transaction(async () => {
    await run('UPDATE bank_connections SET status=?,encrypted_token=NULL WHERE user_id=? AND status=?', 'disconnected', req.user.id, 'connected');
    await audit(req.user.id, null, 'bank_disconnected', 'Statement matching access closed; historical expenses and matches retained.');
  });
  res.json({
    ok: true
  });
});
