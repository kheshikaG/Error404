import {aiConnected,aiMode} from '../services/ai.js';
import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'node:crypto';
import { rateLimit } from 'express-rate-limit';
import { all, get, run, transaction, audit } from '../database/db.js';
import { z, assert, currency } from '../middleware/validation.js';
import { auth, issueSession, clearSession, safeUser, reauthenticate } from '../middleware/auth.js';
import { encrypt, decrypt, base32, verifyTotp } from '../services/encryption.js';
export const authRoutes = Router();
const limiter = rateLimit({
  windowMs: 15 * 60000,
  limit: 20,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: {
    error: 'Too many attempts. Try again in 15 minutes.'
  }
});
authRoutes.post('/auth/register', limiter, async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(1).max(80),
    email: z.email().max(254).transform(v => v.toLowerCase()),
    password: z.string().min(12).max(72).refine(v => Buffer.byteLength(v, 'utf8') <= 72, 'Password must be at most 72 UTF-8 bytes.')
  }).parse(req.body);
  assert(!(await get('SELECT id FROM users WHERE email=?', d.email)), 'This email cannot be registered.');
  const hash = await bcrypt.hash(d.password, 12);
  const uid = await transaction(async () => {
    const id = Number((await run('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)', d.name, d.email, hash)).lastInsertRowid);
    await audit(id, null, 'account_registered');
    return id;
  });
  await issueSession(res, uid);
  res.status(201).json(safeUser(await get('SELECT * FROM users WHERE id=?', uid)));
});
const dummy = bcrypt.hashSync(randomBytes(24).toString('hex'), 12);
authRoutes.post('/auth/login', limiter, async (req, res) => {
  const d = z.object({
    email: z.string().max(254),
    password: z.string().max(72),
    code: z.string().max(6).optional()
  }).parse(req.body);
  const u = await get('SELECT * FROM users WHERE email=? AND status=?', d.email, 'active');
  const ok = await bcrypt.compare(d.password, u?.password_hash || dummy);
  assert(u && ok, 'Email or password is incorrect.', 401);
  if (u.mfa_enabled) {
    const c = verifyTotp(decrypt(u.mfa_secret), d.code, u.mfa_last_counter);
    assert(c >= 0, 'Enter a valid, unused authenticator code.', 401);
    const used=await run('UPDATE users SET mfa_last_counter=? WHERE id=? AND mfa_last_counter<?', c, u.id,c);
    assert(used.changes===1,'This authenticator code was already used.',401);
  }
  await clearSession(req, res);
  await issueSession(res, u.id);
  await audit(u.id, null, 'login');
  res.json(safeUser(u));
});
authRoutes.post('/auth/logout', auth, async (req, res) => {
  await clearSession(req, res);
  await audit(req.user.id, null, 'logout');
  res.json({
    ok: true
  });
});
authRoutes.get('/me', auth, (req, res) => res.json({
  ...safeUser(req.user),
  ai_mode: aiMode(),
  ai_enabled: aiConnected(),
  voice_transcription: !!process.env.GEMINI_API_KEY,
  secure_cookie: process.env.NODE_ENV === 'production'
}));
authRoutes.put('/me', auth, async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(1).max(80),
    currency,
    timezone: z.string().max(80).refine(v => {
      try {
        new Intl.DateTimeFormat('en', {
          timeZone: v
        });
        return true;
      } catch {
        return false;
      }
    }, 'Invalid timezone.'),
    notifications_enabled: z.boolean(),
    photo: z.string().max(200000).nullable().optional().refine(v => !v || /^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(v), 'Use a PNG or JPEG profile photo.')
  }).parse(req.body);
  await run('UPDATE users SET name=?,currency=?,timezone=?,notifications_enabled=?,photo=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', d.name, d.currency, d.timezone, +d.notifications_enabled, d.photo || null, req.user.id);
  await audit(req.user.id, null, 'profile_updated');
  res.json({
    ok: true
  });
});
authRoutes.post('/security/mfa/setup', auth, limiter, async (req, res) => {
  await reauthenticate(req.user, req.body.password);
  assert(!req.user.mfa_enabled, 'MFA is already enabled.');
  const secret = randomBytes(20);
  await run('UPDATE users SET mfa_pending=? WHERE id=?', encrypt(secret.toString('hex')), req.user.id);
  const encoded = base32(secret);
  res.json({
    secret: encoded,
    uri: `otpauth://totp/SplitSmart:${encodeURIComponent(req.user.email)}?secret=${encoded}&issuer=SplitSmart&algorithm=SHA1&digits=6&period=30`
  });
});
authRoutes.post('/security/mfa/enable', auth, limiter, async (req, res) => {
  assert(req.user.mfa_pending, 'Start MFA setup first.');
  const c = verifyTotp(decrypt(req.user.mfa_pending), req.body.code);
  assert(c >= 0, 'Invalid authenticator code.');
  await transaction(async () => {
    await run('UPDATE users SET mfa_secret=mfa_pending,mfa_pending=NULL,mfa_enabled=1,mfa_last_counter=? WHERE id=?', c, req.user.id);
    await run('DELETE FROM sessions WHERE user_id=?', req.user.id);
    await audit(req.user.id, null, 'mfa_enabled');
  });
  await issueSession(res, req.user.id);
  res.json({
    ok: true
  });
});
authRoutes.post('/security/mfa/disable', auth, limiter, async (req, res) => {
  await reauthenticate(req.user, req.body.password);
  assert(req.user.mfa_enabled, 'MFA is not enabled.');
  assert(verifyTotp(decrypt(req.user.mfa_secret), req.body.code, req.user.mfa_last_counter) >= 0, 'Invalid authenticator code.');
  await transaction(async () => {
    await run('UPDATE users SET mfa_enabled=0,mfa_secret=NULL,mfa_pending=NULL,mfa_last_counter=-1 WHERE id=?', req.user.id);
    await run('DELETE FROM sessions WHERE user_id=?', req.user.id);
    await audit(req.user.id, null, 'mfa_disabled');
  });
  await issueSession(res, req.user.id);
  res.json({
    ok: true
  });
});
authRoutes.get('/me/export', auth, async (req, res) => res.json({
  profile: safeUser(req.user),
  groups: await all('SELECT g.* FROM groups g JOIN group_members m ON m.group_id=g.id WHERE m.user_id=?', req.user.id),
  expenses: await all('SELECT * FROM expenses WHERE created_by=?', req.user.id),
  payments: await all('SELECT * FROM cash_payments WHERE sender_id=? OR receiver_id=?', req.user.id, req.user.id),
  audit: await all('SELECT * FROM audit_logs WHERE user_id=?', req.user.id)
}));
authRoutes.delete('/me', auth, limiter, async (req, res) => {
  await reauthenticate(req.user, req.body.password);
  if (req.user.mfa_enabled) assert(verifyTotp(decrypt(req.user.mfa_secret), req.body.code, req.user.mfa_last_counter) >= 0, 'Invalid authenticator code.');
  const {
    balances
  } = await import('../services/finance.js');
  for (const m of await all('SELECT group_id FROM group_members WHERE user_id=?', req.user.id)) {
    assert((await balances(m.group_id)).members.find(u => u.id === req.user.id)?.net === 0, 'Settle your group balances before deleting your account.');
  }
  assert(!(await get('SELECT id FROM cash_payments WHERE (sender_id=? OR receiver_id=?) AND status=?', req.user.id, req.user.id, 'pending')), 'Resolve pending payments before deleting your account.');
  await transaction(async () => {
    await run('DELETE FROM sessions WHERE user_id=?', req.user.id);
    await run('UPDATE bank_connections SET encrypted_token=NULL,status=? WHERE user_id=?', 'disconnected', req.user.id);
    await run('UPDATE users SET name=?,email=?,password_hash=?,photo=NULL,mfa_enabled=0,mfa_secret=NULL,mfa_pending=NULL,status=? WHERE id=?', 'Deleted member', `deleted-${randomBytes(16).toString('hex')}@invalid.local`, 'disabled', 'deleted', req.user.id);
    await audit(req.user.id, null, 'account_deleted', 'Shared ledger retained; personal profile anonymized.');
  });
  await clearSession(req, res);
  res.json({
    ok: true
  });
});
