import multer from 'multer';
import {createHash} from 'node:crypto';
import {rateLimit} from 'express-rate-limit';
import {reviewProof} from '../services/payment-proof.js';
import { Router } from 'express';
import { all, get, run, transaction, audit, notify } from '../database/db.js';
import { membership } from '../middleware/authorization.js';
import { z, id, money, currency, method, assert } from '../middleware/validation.js';
import { cents } from '../services/finance.js';
export const paymentRoutes = Router();
paymentRoutes.get('/payments', async (req, res) => res.json(await all('SELECT p.*,s.name AS sender,r.name AS receiver,g.name AS group_name,(SELECT proof_id FROM payment_proof_links WHERE payment_id=p.id) AS proof_id FROM cash_payments p JOIN users s ON s.id=p.sender_id JOIN users r ON r.id=p.receiver_id JOIN groups g ON g.id=p.group_id JOIN group_members m ON m.group_id=p.group_id WHERE m.user_id=? AND g.archived=0 ORDER BY p.id DESC', req.user.id)));
paymentRoutes.get('/payments/pending', async (req, res) => res.json(await all('SELECT * FROM cash_payments WHERE receiver_id=? AND status=?', req.user.id, 'pending')));
paymentRoutes.post('/payments/cash', async (req, res) => {
  const d = z.object({
    group_id: id,
    receiver_id: id,
    amount: money,
    currency,
    payment_method: method,
    notes: z.string().max(1000).default(''),
    proof_id: id.optional()
  }).parse(req.body);
  const m = await membership(req.user.id, d.group_id);
  await membership(d.receiver_id, d.group_id);
  assert(req.user.id !== d.receiver_id, 'Choose another member.');
  assert(d.currency === m.currency, 'Use the group currency.');
  assert(!['Bank transfer','Mobile payment'].includes(d.payment_method)||d.proof_id,'Upload payment proof for bank or mobile transfers.');
  const pid = await transaction(async () => {
    if(d.proof_id){
      const proof=await get('SELECT * FROM payment_proofs WHERE id=? AND user_id=?',d.proof_id,req.user.id);
      assert(proof && proof.group_id===d.group_id && proof.receiver_id===d.receiver_id && proof.amount===cents(d.amount) && proof.currency===d.currency,'Proof does not match this payment.',400);
      assert(!(await get('SELECT 1 FROM payment_proof_links l JOIN payment_proofs f ON f.id=l.proof_id JOIN cash_payments p ON p.id=l.payment_id WHERE f.content_hash=? AND p.status!=?',proof.content_hash,'cancelled')),'This proof is already attached to another payment.',409);
      assert(!(await get('SELECT 1 FROM payment_proof_links WHERE proof_id=?',d.proof_id)),'Proof already used.',409);
    }
    const pid = Number((await run('INSERT INTO cash_payments(group_id,sender_id,receiver_id,amount,currency,payment_method,notes) VALUES(?,?,?,?,?,?,?)', d.group_id, req.user.id, d.receiver_id, cents(d.amount), d.currency, d.payment_method, d.notes)).lastInsertRowid);
    if(d.proof_id)await run('INSERT INTO payment_proof_links(payment_id,proof_id) VALUES(?,?)',pid,d.proof_id);
    await notify(d.receiver_id, d.group_id, `${req.user.name} says they paid you ${d.currency} ${d.amount} by ${d.payment_method}. Did you receive it?`, pid);
    await audit(req.user.id, d.group_id, 'payment_claimed', `${d.currency} ${d.amount} to member ${d.receiver_id}`);
    return pid;
  });
  res.status(201).json({
    id: pid,
    status: 'pending'
  });
});
for (const [action, status] of [['confirm', 'confirmed'], ['dispute', 'disputed'], ['cancel', 'cancelled']]) paymentRoutes.post(`/payments/:id/${action}`, async (req, res) => {
  const p = await get('SELECT * FROM cash_payments WHERE id=?', id.parse(req.params.id));
  assert(p, 'Payment not found.', 404);
  await membership(req.user.id, p.group_id);
  assert((action === 'cancel' ? p.sender_id : p.receiver_id) === req.user.id, action === 'cancel' ? 'Only the sender can cancel.' : 'Only the receiver can verify this payment.', 403);
  assert(p.status === 'pending', 'This payment is no longer pending.', 409);
  await transaction(async () => {
    const result = await run('UPDATE cash_payments SET status=?,confirmed_at=CASE WHEN ?=? THEN CURRENT_TIMESTAMP ELSE confirmed_at END,disputed_at=CASE WHEN ?=? THEN CURRENT_TIMESTAMP ELSE disputed_at END WHERE id=? AND status=?', status, status, 'confirmed', status, 'disputed', p.id, 'pending');
    assert(result.changes === 1, 'Payment already processed.', 409);
    if (status === 'confirmed') await run('INSERT INTO settlements(payment_id,confirmed_by) VALUES(?,?)', p.id, req.user.id);
    await notify(action === 'cancel' ? p.receiver_id : p.sender_id, p.group_id, `Payment ${status}: ${p.currency} ${(p.amount / 100).toFixed(2)}.`, p.id);
    await audit(req.user.id, p.group_id, `payment_${status}`, `${p.currency} ${(p.amount / 100).toFixed(2)}`);
  });
  res.json({
    ok: true,
    status
  });
});

const proofLimit=rateLimit({windowMs:60000,limit:6,standardHeaders:'draft-8',legacyHeaders:false,message:{error:'Please wait a minute before uploading more payment proofs.'}});
const proofUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1,fields:5}});
paymentRoutes.post('/payments/proofs',proofLimit,proofUpload.single('proof'),async(req,res)=>{
 const d=z.object({group_id:id,receiver_id:id,amount:z.coerce.number().pipe(money),currency,consent:z.enum(['yes','no']).default('no')}).parse(req.body);
 const m=await membership(req.user.id,d.group_id);await membership(d.receiver_id,d.group_id);
 assert(req.user.id!==d.receiver_id && m.currency===d.currency,'Choose another member and the group currency.');
 const b=req.file?.buffer;assert(b,'Choose a payment proof.');let mime;
 if(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))mime='image/png';
 if(b[0]===255&&b[1]===216&&b[2]===255)mime='image/jpeg';
 if(b.subarray(0,5).toString()==='%PDF-')mime='application/pdf';
 assert(mime,'Only JPG, PNG, and PDF payment proofs are supported.');
 const digest=createHash('sha256').update(b).digest('hex');
 const analysis=await reviewProof(b,mime,{amount:cents(d.amount),currency:d.currency},d.consent==='yes');
 const saved=await run('INSERT INTO payment_proofs(user_id,group_id,receiver_id,amount,currency,mime,content,content_hash,analysis_json) VALUES(?,?,?,?,?,?,?,?,?)',req.user.id,d.group_id,d.receiver_id,cents(d.amount),d.currency,mime,b,digest,JSON.stringify(analysis));
 res.status(201).json({id:Number(saved.lastInsertRowid),analysis});
});
async function paymentProof(req){
 const p=await get('SELECT f.* FROM payment_proofs f JOIN payment_proof_links l ON l.proof_id=f.id JOIN cash_payments p ON p.id=l.payment_id WHERE p.id=? AND (p.sender_id=? OR p.receiver_id=?)',id.parse(req.params.id),req.user.id,req.user.id);
 assert(p,'Payment proof unavailable.',404);await membership(req.user.id,p.group_id);return p;
}
paymentRoutes.get('/payments/:id/proof',async(req,res)=>{const p=await paymentProof(req);res.json({analysis:JSON.parse(p.analysis_json),created_at:p.created_at});});
paymentRoutes.get('/payments/:id/proof/file',async(req,res)=>{const p=await paymentProof(req);res.set('Content-Disposition','attachment; filename="payment-proof.'+(p.mime==='application/pdf'?'pdf':p.mime==='image/png'?'png':'jpg')+'"').type(p.mime).send(Buffer.from(p.content));});
