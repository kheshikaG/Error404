import {receiptFromText} from '../public/receipt-text.js';
import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import multer from 'multer';
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';
const uploadPath = process.env.UPLOADS_PATH || './uploads';
import { readFileSync, existsSync } from 'node:fs';
import { all, get, run, batch, transaction } from '../database/db.js';
import { z, id, assert } from '../middleware/validation.js';
import { membership } from '../middleware/authorization.js';
import { parseExpense, extractReceipt, aiConnected, chatAssistant, transcribeAudio } from '../services/ai.js';
export const aiRoutes = Router();
const limit = rateLimit({
  windowMs: 60000,
  limit: 12,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: {
    error: 'Please wait a minute before asking again.'
  }
});
aiRoutes.post('/ai/parse-expense', limit, async (req, res) => {
  const d = z.object({
    group_id: id,
    text: z.string().trim().min(1).max(2000)
  }).parse(req.body);
  const m = await membership(req.user.id, d.group_id);
  const members = await all('SELECT u.id,u.name FROM users u JOIN group_members m ON m.user_id=u.id WHERE m.group_id=?', d.group_id);
  const today = new Intl.DateTimeFormat('en-CA', {
    timeZone: req.user.timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
  res.json(await parseExpense(d.text, {
    members,
    user: req.user,
    currency: m.currency,
    today
  }));
});
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024,
    files: 1,
    fields: 5
  }
});
aiRoutes.post('/receipts/upload', limit, upload.single('receipt'), async (req, res) => {
  const f = req.file;
  assert(f, 'Choose a JPG, PNG, or PDF receipt.');
  const b = f.buffer;
  let mime;
  if (b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) mime = 'image/png';
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) mime = 'image/jpeg';
  if (b.subarray(0, 5).toString() === '%PDF-') mime = 'application/pdf';
  assert(mime, 'Only valid JPG, PNG, or PDF files are accepted.');
  const cloud = req.body.extraction === 'cloud';
  assert(!cloud || (aiConnected() && req.body.consent === 'yes'), 'Confirm sending this receipt to the connected AI provider.');
  const text=z.string().max(20000).parse(req.body.ocr_text||'');
  const extracted = cloud ? await extractReceipt(b, mime) : receiptFromText(text);
  if(!text && !cloud)extracted.message='File attached. Enter the details manually or scan it on your device.';
  const filename = randomUUID();
  const rid = await transaction(async () => {
      const rid = Number((await run('INSERT INTO receipts(user_id,filename,mime,extracted_json) VALUES(?,?,?,?)', req.user.id, filename, mime, JSON.stringify(extracted))).lastInsertRowid);
      await run('INSERT INTO receipt_files(receipt_id,content) VALUES(?,?)',rid,b);
      if(extracted.items.length)await batch(extracted.items.map(item=>({sql:'INSERT INTO receipt_items(receipt_id,description,quantity,amount) VALUES(?,?,?,?)',args:[rid,item.description,item.quantity,Math.round(item.amount*100)]})));
      return rid;
    });
  res.status(201).json({
    id: rid,
    ...extracted
  });
});
aiRoutes.get('/receipts/:id', async (req, res) => {
  const r = await get('SELECT * FROM receipts WHERE id=?', id.parse(req.params.id));
  assert(r, 'Receipt not found.', 404);
  const attached = await get('SELECT group_id FROM expenses WHERE receipt_id=? AND status=?', r.id, 'active');
  if (r.user_id !== req.user.id) {
    assert(attached, 'Receipt not available.', 403);
    await membership(req.user.id, attached.group_id);
  }
  const file=await get('SELECT content FROM receipt_files WHERE receipt_id=?',r.id);
  const legacy=join(uploadPath,r.filename);
  assert(file||existsSync(legacy),'Receipt file is unavailable.',404);
  const content=file?Buffer.from(file.content):readFileSync(legacy);
  res.set('Content-Disposition', 'attachment; filename="receipt.' + (r.mime === 'application/pdf' ? 'pdf' : r.mime === 'image/png' ? 'png' : 'jpg') + '"').type(r.mime).send(content);
});

aiRoutes.post('/ai/chat',limit,async(req,res)=>{
 const d=z.object({group_id:id,messages:z.array(z.object({role:z.enum(['user','assistant']),content:z.string().trim().min(1).max(2000)})).min(1).max(12)}).parse(req.body);
 assert(d.messages.at(-1).role==='user','Send a message first.');
 const m=await membership(req.user.id,d.group_id);
 const members=await all('SELECT u.id,u.name FROM users u JOIN group_members m ON m.user_id=u.id WHERE m.group_id=?',d.group_id);
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:req.user.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 res.json(await chatAssistant(d.messages,{members,user:req.user,currency:m.currency,today}));
});
const audioUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:4*1024*1024,files:1,fields:1}});
aiRoutes.post('/ai/transcribe',limit,audioUpload.single('audio'),async(req,res)=>{
 assert(req.body.consent==='yes','Confirm sending your voice message to Gemini.');
 const b=req.file?.buffer;
 assert(b&&b.length>=44&&b.subarray(0,4).toString()==='RIFF'&&b.subarray(8,12).toString()==='WAVE','Record a WAV voice message first.');
 res.json(await transcribeAudio(b));
});
