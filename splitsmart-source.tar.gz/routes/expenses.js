import { Router } from 'express';
import { all, get, run, batch, transaction, audit, notify } from '../database/db.js';
import { membership, editableExpense } from '../middleware/authorization.js';
import { expenseSchema, assert, id, z } from '../middleware/validation.js';
import { splitExpense, cents, detectDuplicate } from '../services/finance.js';
export const expenseRoutes = Router();
export async function validateExpense(uid, gid, body, exclude = 0) {
  const e = expenseSchema.parse(body);
  const m = await membership(uid, gid);
  assert(e.currency === m.currency, 'Use the group currency. Create a separate group for another currency.');
  await membership(e.payer_id, gid);
  await Promise.all(e.participants.map(async u => await membership(u, gid)));
  if (e.receipt_id) assert(await get('SELECT id FROM receipts WHERE id=? AND user_id=?', e.receipt_id, uid), 'Receipt not found.', 403);
  const shares = splitExpense(e);
  const duplicates = await detectDuplicate(gid, e, exclude);
  return {
    e,
    shares,
    duplicates
  };
}
async function store(uid, gid, body, eid = 0) {
  const {
    e,
    shares,
    duplicates
  } = await validateExpense(uid, gid, body, eid);
  if (duplicates.length && !e.duplicate_ack) {
    const err = new Error('Possible duplicate. Review these expenses before continuing.');
    err.status = 409;
    err.duplicates = duplicates;
    throw err;
  }
  return await transaction(async () => {
    await run('INSERT OR IGNORE INTO categories(name) VALUES(?)', e.category);
    const cat = (await get('SELECT id FROM categories WHERE name=?', e.category)).id;
    const reasons = [];
    if (cents(e.amount) > 10000000) reasons.push('Unusually large amount');
    if (duplicates.length) reasons.push('Possible duplicate; user kept both');
    if (e.receipt_id) {
      const r = JSON.parse((await get('SELECT extracted_json FROM receipts WHERE id=?', e.receipt_id)).extracted_json || '{}');
      if (r.amount && cents(r.amount) !== cents(e.amount)) reasons.push('Receipt total differs');
    }
    const args = [e.description, cents(e.amount), e.currency, cat, e.payer_id, e.payment_method, e.expense_date, e.receipt_id || null, e.notes, e.split_type, reasons.join('; ') || null];
    if (eid) {
      assert(!(await get('SELECT id FROM transaction_matches WHERE expense_id=?', eid)), 'Unmatch the bank transaction before editing this expense.');
      await run('UPDATE expenses SET description=?,amount=?,currency=?,category_id=?,payer_id=?,payment_method=?,expense_date=?,receipt_id=?,notes=?,split_type=?,review_reason=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', ...args, eid);
      await run('DELETE FROM expense_shares WHERE expense_id=?', eid);
      await run('DELETE FROM expense_items WHERE expense_id=?', eid);
    } else eid = Number((await run('INSERT INTO expenses(description,amount,currency,category_id,payer_id,payment_method,expense_date,receipt_id,notes,split_type,review_reason,group_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', ...args, gid, uid)).lastInsertRowid);
    await batch(shares.map(s=>({sql:'INSERT INTO expense_shares(expense_id,user_id,share_type,share_amount,percentage) VALUES(?,?,?,?,?)',args:[eid,s.user_id,e.split_type,s.amount,e.split_type==='percentage'?e.values[e.participants.indexOf(s.user_id)]:null]})));
    if(e.items.length)await batch(e.items.map(i=>({sql:'INSERT INTO expense_items(expense_id,description,quantity,amount,participants) VALUES(?,?,?,?,?)',args:[eid,i.description,i.quantity,cents(i.amount),JSON.stringify(i.participants)]})));
    await audit(uid, gid, body.id ? 'expense_modified' : 'expense_saved', `${e.description}: ${e.currency} ${e.amount}`);
    const others=await all('SELECT user_id FROM group_members WHERE group_id=? AND user_id!=?',gid,uid);
    if(others.length)await batch(others.map(m=>({sql:'INSERT INTO notifications(user_id,group_id,message) VALUES(?,?,?)',args:[m.user_id,gid,`${e.description} was saved (${e.currency} ${e.amount}).${reasons.length?' Needs review.':''}`]})));
    return {
      id: eid,
      shares,
      review_reason: reasons
    };
  });
}
expenseRoutes.get('/categories', async (req, res) => res.json(await all('SELECT * FROM categories ORDER BY name')));
expenseRoutes.get('/groups/:id/expenses', async (req, res) => {
  await membership(req.user.id, req.params.id);
  const rows = await all('SELECT e.*,u.name AS payer,c.name AS category,tm.id AS match_id FROM expenses e JOIN users u ON u.id=e.payer_id LEFT JOIN categories c ON c.id=e.category_id LEFT JOIN transaction_matches tm ON tm.expense_id=e.id WHERE e.group_id=? AND e.status=? ORDER BY e.expense_date DESC,e.id DESC', Number(req.params.id), 'active');
  res.json(await Promise.all(rows.map(async e => ({
    ...e,
    shares: await all('SELECT * FROM expense_shares WHERE expense_id=?', e.id),
    items: (await all('SELECT * FROM expense_items WHERE expense_id=?', e.id)).map(i => ({
      ...i,
      participants: JSON.parse(i.participants)
    }))
  }))));
});
expenseRoutes.post('/groups/:id/expenses/preview', async (req, res) => {
  let exclude = 0;
  if (req.body.id) {
    const current = await editableExpense(req.user.id, req.body.id);
    assert(current.group_id === id.parse(req.params.id), 'An expense cannot be moved between groups.');
    exclude = current.id;
  }
  res.json(await validateExpense(req.user.id, id.parse(req.params.id), req.body, exclude));
});
expenseRoutes.post('/groups/:id/expenses', async (req, res) => res.status(201).json(await store(req.user.id, id.parse(req.params.id), req.body)));
expenseRoutes.put('/expenses/:id', async (req, res) => {
  const e = await editableExpense(req.user.id, req.params.id);
  res.json(await store(req.user.id, e.group_id, {
    ...req.body,
    id: e.id
  }, e.id));
});
expenseRoutes.delete('/expenses/:id', async (req, res) => {
  const e = await editableExpense(req.user.id, req.params.id);
  assert(!(await get('SELECT id FROM transaction_matches WHERE expense_id=?', e.id)), 'Unmatch the bank transaction before deleting this expense.');
  await transaction(async () => {
    await run('UPDATE expenses SET status=? WHERE id=?', 'deleted', e.id);
    await audit(req.user.id, e.group_id, 'expense_deleted', e.description);
  });
  res.json({
    ok: true
  });
});
expenseRoutes.post('/expenses/:id/review', async (req, res) => {
  const e = await editableExpense(req.user.id, req.params.id);
  await run('UPDATE expenses SET review_reason=NULL WHERE id=?', e.id);
  await audit(req.user.id, e.group_id, 'expense_reviewed', e.description);
  res.json({
    ok: true
  });
});
expenseRoutes.get('/groups/:id/export', async (req, res) => {
  await membership(req.user.id, req.params.id);
  const rows = await all('SELECT e.expense_date,e.description,u.name AS payer,e.amount,e.currency,c.name AS category FROM expenses e JOIN users u ON u.id=e.payer_id LEFT JOIN categories c ON c.id=e.category_id WHERE group_id=? AND e.status=?', Number(req.params.id), 'active');
  const quote = v => '"' + String(v ?? '').replace(/^[=+@\-\t\r]/, "'$&").replaceAll('"', '""') + '"';
  res.type('text/csv').attachment('splitsmart-expenses.csv').send(['Date,Description,Payer,Amount,Currency,Category', ...rows.map(r => [r.expense_date, r.description, r.payer, (r.amount / 100).toFixed(2), r.currency, r.category].map(quote).join(','))].join('\r\n'));
});
