# SplitSmart

Split expenses. Verify payments. Stay in control.

This version uses real accounts and user-entered financial records. No default users, sample expenses, simulated bank feed, or fallback AI answers are included.

## Local setup

Use Node.js 24 and run from this folder:

```sh
npm install
npm run setup
npm run db:init
npm start
```

Open http://localhost:3000 and create your account. `setup` creates `.env` with random secrets; it never overwrites an existing configuration. For the exact tested dependency resolutions, use `pnpm install --frozen-lockfile` instead of `npm install`.

## Free shared hosting

See [DEPLOYMENT.md](DEPLOYMENT.md). The included Render blueprint selects its **Free** web-service plan with **no paid disk**. Turso's **Free** libSQL database stores accounts, groups, sessions, expenses, invitations, statement transactions, audit logs, and receipt bytes. This avoids losing records when a free server restarts. Accounts and credentials with the hosting providers are required; the configuration does not itself create a live URL.

Production startup requires `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`, `SESSION_SECRET`, and `ENCRYPTION_KEY`. The assigned Render HTTPS URL automatically becomes `APP_ORIGIN`; set it explicitly when using a custom domain. Keep the database and host on their free plans and do not enable overages or upgrades.

Local development uses Node's SQLite engine. Hosted operation uses async SQL over HTTPS via `@libsql/client/web`. Financial transactions retain commit/rollback semantics; dependent queries use a transaction-specific client through AsyncLocalStorage. Bulk inserts use batches. Local transactions serialize access to avoid interleaving unrelated requests.

## Invite your teammates

1. Open the deployed URL and register your own account.
2. Create a group and open **Manage group → Create invitation link**.
3. Share the single-use link with one teammate. It expires after seven days.
4. They register or sign in, review the group invitation, and click **Join group**.
5. Generate one link for each additional teammate.

The token is carried in a URL fragment and stored only as a hash. Membership is granted after acceptance; reused/expired invitations fail. Existing users can also be added by email. Each person has their own login. `localhost` cannot be shared with people on other computers.

## Features

- Account registration/login, bcrypt passwords, server-side sessions, profiles, optional authenticator-app TOTP, data export, and account anonymization.
- Groups, roles, invitations, member balances, and settled-group archival.
- Equal, percentage, exact, and item-based expense splits, including shared item/tax rows. Integer cents preserve the total exactly.
- Manual expense entry and a review screen before saving; custom categories, dates, notes, receipt attachments, search/filter, CSV export, and browser print/PDF.
- Sender payment claims, receiver-only confirmation/dispute, and cancellation while pending. Only confirmed payments change balances. The app never transfers money.
- Settlement suggestions, duplicate acknowledgement, neutral review flags, private notifications, and audit history.
- Real bank-statement CSV import with preview and explicit confirmation, followed by user-confirmed purchase matching.

Each group has one currency: MUR, USD, EUR, GBP, ZAR, INR, AUD, or CAD. No silent exchange-rate conversion occurs. Members with ledger history remain for balance attribution; settled groups can be archived.

## Receipt scanning, camera and voice

Use **Scan a receipt → Open camera → Capture receipt → Scan and review**, or choose a JPG, PNG, or one-page PDF up to 5 MB. The default Tesseract OCR runs on the user's device with self-hosted assets and requires no AI key. It recognizes printed English text and suggests a merchant, an unambiguous labelled total, and ISO dates. Uncertain fields stay blank; raw recognized text is available for review. Items and ambiguous dates are entered manually. Poor lighting, blur, handwriting and unusual layouts reduce accuracy.

Camera access requires HTTPS (or localhost), browser permission, and an available camera. Camera tracks stop when the dialog closes or the page is hidden. A phone's rear camera is preferred.

For the conversational assistant, set **GEMINI_API_KEY** in Render using a Google AI Studio project without billing. The default model is `gemini-3.5-flash-lite`; override it with `GEMINI_MODEL` if necessary. Free-tier quotas apply. No automatic paid fallback exists. Google may use free-tier inputs to improve its products, so users are informed before sending messages or selecting cloud receipt extraction. The existing OpenAI adapter remains available through `AI_API_KEY` when Gemini is unset.

The AI Assistant supports chat history, expense drafts, browser speech dictation, up to 30-second recorded WAV messages sent to Gemini for transcription on request, audio preview, and optional spoken replies. Dictation availability depends on the browser and may use its online speech service. Recorded transcription requires Gemini; read-aloud uses browser speech synthesis. This is turn-by-turn voice interaction, not an always-listening call. Transcripts can be edited before sending.

AI responses never directly modify the ledger. Suggested expenses open the existing validated review and confirmation flow. Cloud receipt extraction is optional and requires an explicit consent checkbox. Receipts are stored in the database and downloaded only after authorization.

`npm install` or `pnpm install` prepares the self-hosted OCR assets through the root postinstall script. If lifecycle scripts were disabled, run `node scripts/prepare-ocr.js`. The generated `public/vendor` folder is excluded from source control; package versions are pinned by `pnpm-lock.yaml`.

## Bank statements

Upload a UTF-8 CSV with these column names:

```text
date,merchant,amount,currency
```

Use YYYY-MM-DD dates, negative amounts for purchases, at most two decimals, and currency codes such as MUR. Quoted merchant names containing commas are supported. Maximum 200 KB and 1,000 rows. Review the preview before confirming. Imports are private to the uploader; identical complete imports are blocked. Avoid overlapping statement periods because partial overlap is not automatically deduplicated.

Matches require the uploader to be the expense payer, a group member, and owner of the imported transaction. Amount, currency, and uniqueness are checked. Matching a purchase does not settle a debt between members. Imported statements are user-provided records, not independent bank verification.

Automatic Open Banking is **not connected**. A real provider and provider-specific OAuth/consent integration are needed. No bank password, PIN, OTP, CVV, or money-moving permission is requested.

## Structure

```text
splitsmart/
  server.js
  package.json / pnpm-lock.yaml
  .env.example / .gitignore / .dockerignore
  Dockerfile / render.yaml
  README.md / DEPLOYMENT.md / VALIDATION.md
  scripts/setup.js / environment.js
  database/db.js / schema.sql / init.js
  middleware/auth.js / authorization.js / validation.js
  routes/auth.js / groups.js / invitations.js / expenses.js
  routes/payments.js / ai.js / bank.js / activity.js
  services/finance.js / ai.js / encryption.js / statements.js
  public/index.html / app.js / styles.css / assets/favicon.svg
  tests/core.test.js
```

Vanilla frontend → Express REST API → SQLite locally or Turso remotely. SQL queries are parameterized, foreign keys/checks/unique constraints preserve integrity, and multi-record writes use transactions. API expense inputs use major currency units; ledger amounts/balances use integer cents.

## API

All mutations require `X-SplitSmart: 1`. Browser origin must match `APP_ORIGIN`. Everything except auth registration/login and health requires an HTTP-only session cookie.

| Routes | Purpose |
| --- | --- |
| `GET /api/health` | Liveness |
| `POST /api/auth/register`, `/login`, `/logout` | Authentication |
| `GET/PUT/DELETE /api/me`, `GET /api/me/export` | Account/profile |
| `POST /api/security/mfa/setup`, `/enable`, `/disable` | Authenticator management |
| `GET/POST /api/groups`, `GET/PUT/DELETE /api/groups/:id` | Groups |
| `POST /api/groups/:id/members`, `PUT/DELETE /api/groups/:id/members/:uid` | Membership/roles |
| `POST /api/groups/:id/invitations` | Single-use link |
| `POST /api/invitations/inspect`, `/accept` | Invitation review/acceptance |
| `GET /api/groups/:id/balances` | Balances and settlement suggestions |
| `GET/POST /api/groups/:id/expenses`, `POST /api/groups/:id/expenses/preview` | Expenses/review |
| `PUT/DELETE /api/expenses/:id`, `POST /api/expenses/:id/review` | Creator-owned changes |
| `GET /api/groups/:id/export`, `GET /api/categories` | Export/categories |
| `GET /api/payments`, `/api/payments/pending` | Payment lists |
| `POST /api/payments/cash`, `POST /api/payments/:id/confirm`, `/dispute`, `/cancel` | Claims and verification |
| `POST /api/ai/parse-expense`, `POST /api/receipts/upload`, `GET /api/receipts/:id` | Drafts/receipts |
| `POST /api/bank/import/preview`, `/import`, `GET /api/bank/transactions` | Statement import |
| `POST /api/bank/match`, `/dismiss`, `/disconnect`, `DELETE /api/bank/matches/:eid` | Matching |
| `GET /api/notifications`, `POST /api/notifications/:id/read`, `GET /api/audit-logs` | Private activity |

Notifications and audit logs paginate with `?offset=0`, 50 rows per page.

## Security and limits

Implemented: bcrypt cost 12; random opaque sessions stored as HMAC hashes; HTTP-only, strict same-site cookies; Secure cookies/HSTS in production; CSRF origin/header checks; Helmet/CSP; rate limiting; escaped HTML; authorization on the server; AES-256-GCM for MFA secrets; TOTP replay checks; and read-only audit access for normal users.

Keep `.env`, receipt/database data, and API tokens out of Git. The previous development database was preserved locally but is no longer used by the app or included in deployment artifacts. No old accounts are migrated automatically.

The app is deployed at https://splitsmart-bheejay01.onrender.com/. It has not undergone security certification. External AI verification, provider banking, load/security review, email verification/password reset, MFA recovery, malware scanning, managed backups, retention rules, and push notifications require further work. Rate limits are in-process and the current free-host configuration uses one instance. Free-tier quotas and sleeping servers limit availability. Read the deployment and validation documents for the scope of completed checks.

## Payment proof verification update

Bank and mobile transfer claims require a JPG, PNG or PDF proof (up to 5 MB). Files and extracted details are accessible only to the sender and recipient. Sending documents to AI requires explicit consent. AI reads details and flags mismatched amounts, currencies and incomplete transfers; it never authenticates a document or settles a payment. AI outages fall back to recipient review. The receiver must check their account and confirm; pending, disputed and cancelled payments do not affect the ledger. Exact attached proof reuse is blocked for non-cancelled payments, but altered screenshots cannot be reliably detected. Receiver requests are in-app notifications, not email or SMS. Existing records are preserved.

Real my.t wallet movements remain unconnected pending the approved API documentation, credentials, and verified callback integration. Do not collect bank passwords or wallet PINs in SplitSmart. Official provider overview: https://www.myt.mu/money/business-solutions

Wallet navigation is provider-neutral and clearly marked Not connected. Cash-in, sending money and cash-out are disabled until a real payment integration is available. External mobile payment recording and verification remain available.
