import { get } from '../database/db.js';
import { assert, id } from './validation.js';
export async function membership(uid, gid, admin = false) {
  gid = id.parse(gid);
  const m = await get('SELECT m.*,g.currency,g.name FROM group_members m JOIN groups g ON g.id=m.group_id WHERE m.user_id=? AND m.group_id=? AND g.archived=0', uid, gid);
  assert(m, "You don't have permission to access this group.", 403);
  if (admin) assert(['owner', 'admin'].includes(m.role), 'A group admin must perform this action.', 403);
  return m;
}
export async function editableExpense(uid, eid) {
  const e = await get('SELECT * FROM expenses WHERE id=? AND status=?', id.parse(eid), 'active');
  assert(e, 'Expense not found.', 404);
  await membership(uid, e.group_id);
  assert(e.created_by === uid, 'Only the expense creator can change it.', 403);
  return e;
}
