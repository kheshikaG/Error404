import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { get, run } from '../database/db.js';
import { assert } from './validation.js';
const secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) throw new Error('SESSION_SECRET must contain at least 32 characters. Run npm run setup.');
export const tokenHash = token => createHmac('sha256', secret).update(token).digest('hex');
const cookie = {
  httpOnly: true,
  sameSite: 'strict',
  secure: process.env.NODE_ENV === 'production',
  path: '/'
};
export async function issueSession(res, uid) {
  const token = randomBytes(32).toString('hex');
  await run('DELETE FROM sessions WHERE expires_at<?', Date.now());
  await run('INSERT INTO sessions VALUES(?,?,?)', tokenHash(token), uid, Date.now() + 12 * 3600000);
  res.cookie('ss_session', token, {
    ...cookie,
    maxAge: 12 * 3600000
  });
}
export async function clearSession(req, res) {
  if (req.cookies.ss_session) await run('DELETE FROM sessions WHERE token_hash=?', tokenHash(req.cookies.ss_session));
  res.clearCookie('ss_session', cookie);
}
export async function auth(req, res, next) {
  const token = req.cookies.ss_session;
  const user = token && (await get('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.status=?', tokenHash(token), Date.now(), 'active'));
  assert(user, 'Please sign in to continue.', 401);
  req.user = user;
  next();
}
export function sameOrigin(req, res, next) {
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    const origin = req.headers.origin;
    assert(!origin || origin === process.env.APP_ORIGIN, 'Request origin is not allowed.', 403);
    assert(req.headers['x-splitsmart'] === '1', 'Missing request verification header.', 403);
  }
  next();
}
export const safeUser = u => ({
  id: u.id,
  name: u.name,
  email: u.email,
  currency: u.currency,
  timezone: u.timezone,
  photo: u.photo,
  notifications_enabled: !!u.notifications_enabled,
  mfa_enabled: !!u.mfa_enabled
});
export async function reauthenticate(user, password) {
  assert(typeof password === 'string' && (await bcrypt.compare(password, user.password_hash)), 'Please confirm your current password.', 403);
}
