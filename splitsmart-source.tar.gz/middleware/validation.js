import { z } from 'zod';
export class AppError extends Error { constructor(message,status=400){super(message);this.status=status;} }
export const assert=(condition,message,status=400)=>{if(!condition)throw new AppError(message,status);};
export const id=z.coerce.number().int().positive();
export const currency=z.enum(['MUR','USD','EUR','GBP','ZAR','INR','AUD','CAD']);
export const money=z.number().finite().positive().max(10000000).refine(n=>Math.abs(n*100-Math.round(n*100))<0.00001,'Use at most two decimal places.');
export const method=z.enum(['Cash','Bank transfer','Card','Mobile payment','Other']);
export const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>!Number.isNaN(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s,'Enter a valid date.');
export const expenseSchema=z.object({description:z.string().trim().min(1).max(200),amount:money,currency,payer_id:id,participants:z.array(id).min(1).max(100).refine(v=>new Set(v).size===v.length,'Participants must be unique.'),split_type:z.enum(['equal','percentage','exact','items']),values:z.array(z.number().finite().min(0)).max(100).default([]),items:z.array(z.object({description:z.string().trim().min(1).max(100),amount:money,quantity:z.number().positive().max(10000).default(1),participants:z.array(id).min(1).max(100).refine(v=>new Set(v).size===v.length)})).max(100).default([]),category:z.string().trim().min(1).max(50),expense_date:date,payment_method:method,receipt_id:id.nullable().optional(),notes:z.string().max(2000).default(''),duplicate_ack:z.boolean().default(false)});
export {z};
