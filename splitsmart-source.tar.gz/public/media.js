let camera,worker,scanEpoch=0,recognition,voiceStream,voiceContext,voiceNode,voiceTimer;
let captureFile=null,voiceChunks=[],voiceSamples=0,voiceEpoch=0;
export const capturedReceipt=()=>captureFile;
export function clearCapture(){captureFile=null;}
export function stopCamera(){camera?.getTracks().forEach(t=>t.stop());camera=null;}
export async function startCamera(video){
 stopCamera();
 if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera is unavailable here. Open this HTTPS site in Chrome or Safari, or choose a photo.');
 const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
 if(!video.isConnected||!video.closest('dialog')?.open){stream.getTracks().forEach(t=>t.stop());return;}
 camera=stream;video.srcObject=stream;video.hidden=false;await video.play();
}
export async function takePhoto(video){
 if(!video.videoWidth)throw new Error('Wait for the camera image, then capture.');
 const c=document.createElement('canvas');const scale=Math.min(1,2200/Math.max(video.videoWidth,video.videoHeight));c.width=Math.round(video.videoWidth*scale);c.height=Math.round(video.videoHeight*scale);
 c.getContext('2d').drawImage(video,0,0,c.width,c.height);
 const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.92));if(!blob)throw new Error('Could not capture this frame. Try again.');
 captureFile=new File([blob],'camera-receipt.jpg',{type:'image/jpeg'});stopCamera();video.hidden=true;return captureFile;
}
async function imageCanvas(file){
 const bitmap=await createImageBitmap(file);try{const scale=Math.min(1,2200/Math.max(bitmap.width,bitmap.height));const c=document.createElement('canvas');c.width=Math.round(bitmap.width*scale);c.height=Math.round(bitmap.height*scale);c.getContext('2d').drawImage(bitmap,0,0,c.width,c.height);return c;}finally{bitmap.close();}
}
export async function scanReceipt(file,onProgress=()=>{}){
 const epoch=++scanEpoch;let canvas,pdf,pdfTask,active;
 try{
  onProgress('Preparing receipt…');
  if(file.type==='application/pdf'){
   const lib=await import('/vendor/pdf.min.mjs');lib.GlobalWorkerOptions.workerSrc='/vendor/pdf.worker.min.mjs';
   pdfTask=lib.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false});pdf=await pdfTask.promise;
   if(pdf.numPages!==1)throw new Error('Scan one receipt page at a time. Choose a one-page PDF or take a photo of the receipt.');
   const page=await pdf.getPage(1),base=page.getViewport({scale:1});const viewport=page.getViewport({scale:Math.min(2.5,2200/Math.max(base.width,base.height))});canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;
  }else canvas=await imageCanvas(file);
  if(epoch!==scanEpoch)throw new Error('Scan cancelled.');
  if(!window.Tesseract)throw new Error('Receipt reader did not load. Refresh and try again.');
  active=await window.Tesseract.createWorker('eng',1,{workerPath:'/vendor/worker.min.js',corePath:'/vendor',langPath:'/vendor',workerBlobURL:false,logger:m=>{if(epoch===scanEpoch)onProgress(m.status==='recognizing text'?`Reading receipt… ${Math.round(m.progress*100)}%`:'Loading receipt reader…');}});worker=active;
  if(epoch!==scanEpoch)throw new Error('Scan cancelled.');
  const result=await active.recognize(canvas);if(epoch!==scanEpoch)throw new Error('Scan cancelled.');
  if(!result.data.text.trim())throw new Error('No readable text found. Try brighter light, hold the camera steady, or enter details manually.');
  return result.data.text.slice(0,20000);
 }finally{if(active){await active.terminate().catch(()=>{});if(worker===active)worker=null;}if(pdfTask)await pdfTask.destroy();}
}
export function stopDictation(){recognition?.abort();recognition=null;}
export function dictate(textarea,status){
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;if(!Speech)throw new Error('Live dictation is unavailable in this browser. Use Record voice message below.');
 stopDictation();const r=new Speech();recognition=r;r.lang='en-US';r.interimResults=true;r.continuous=false;const prefix=textarea.value.trim();
 r.onresult=e=>{const spoken=Array.from(e.results,x=>x[0].transcript).join(' ');textarea.value=(prefix?prefix+' ':'')+spoken;};
 r.onerror=e=>{status.textContent=e.error==='not-allowed'?'Microphone permission was denied. Allow it in browser settings, or type.':`Dictation stopped (${e.error}). Try recording or typing.`;};
 r.onend=()=>{if(recognition===r)recognition=null;if(status.textContent==='Listening…')status.textContent='Dictation finished. Review your words before sending.';};r.start();status.textContent='Listening…';
}
function releaseVoice(){voiceEpoch++;clearTimeout(voiceTimer);voiceStream?.getTracks().forEach(t=>t.stop());voiceStream=null;voiceNode?.disconnect();voiceNode=null;const ctx=voiceContext;voiceContext=null;if(ctx)ctx.close().catch(()=>{});}
export async function recordVoice(onStop){
 releaseVoice();stopDictation();voiceChunks=[];voiceSamples=0;
 if(!navigator.mediaDevices?.getUserMedia)throw new Error('Microphone recording is unavailable in this browser.');
 const epoch=voiceEpoch;const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});if(epoch!==voiceEpoch){stream.getTracks().forEach(t=>t.stop());return;}voiceStream=stream;
 try{voiceContext=new AudioContext({sampleRate:16000});await voiceContext.audioWorklet.addModule('/voice-worklet.js');voiceNode=new AudioWorkletNode(voiceContext,'voice-capture');const maxSamples=voiceContext.sampleRate*30;voiceNode.port.onmessage=e=>{if(epoch===voiceEpoch&&voiceSamples<maxSamples){voiceChunks.push(e.data);voiceSamples+=e.data.length;}};const source=voiceContext.createMediaStreamSource(voiceStream);source.connect(voiceNode);voiceNode.connect(voiceContext.destination);await voiceContext.resume();voiceTimer=setTimeout(onStop,30000);}catch(e){releaseVoice();throw e;}
}
export function stopRecording(){
 const rate=voiceContext?.sampleRate||16000;releaseVoice();
 if(!voiceSamples)return null;
 const buffer=new ArrayBuffer(44+voiceSamples*2),view=new DataView(buffer);const str=(o,s)=>{for(let i=0;i<s.length;i++)view.setUint8(o+i,s.charCodeAt(i));};str(0,'RIFF');view.setUint32(4,36+voiceSamples*2,true);str(8,'WAVE');str(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,rate,true);view.setUint32(28,rate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);str(36,'data');view.setUint32(40,voiceSamples*2,true);let offset=44;for(const chunk of voiceChunks)for(const sample of chunk){view.setInt16(offset,Math.max(-1,Math.min(1,sample))*32767,true);offset+=2;}voiceChunks=[];voiceSamples=0;return new File([buffer],'voice-message.wav',{type:'audio/wav'});
}
export function cleanupMedia(){stopCamera();stopDictation();releaseVoice();voiceChunks=[];voiceSamples=0;scanEpoch++;worker?.terminate().catch(()=>{});worker=null;window.speechSynthesis?.cancel();}
export function speak(text){if(!window.speechSynthesis)throw new Error('Read aloud is unavailable in this browser.');speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='en-US';speechSynthesis.speak(u);}
