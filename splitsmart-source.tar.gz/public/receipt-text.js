// Conservative OCR field suggestions. Uncertain values remain blank for review.
export function receiptFromText(text){
 const lines=String(text).slice(0,20000).split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
 const totals=[];
 for(const line of lines){
  if(/\b(sub\s*total|tax|vat|change|cash|tendered|savings)\b/i.test(line))continue;
  if(!/\b(grand\s+total|total(?:\s+due)?|amount\s+(?:due|paid)|balance\s+due)\b/i.test(line))continue;
  const match=line.match(/(?:^|\s|[:$€£])((?:\d{1,3}(?:[, ]\d{3})+|\d+)[.,]\d{2})\s*(?:[A-Z]{3})?\s*$/);
  if(match){let value=match[1].replace(/ /g,'');value=value.includes('.')?value.replace(/,/g,''):value.replace(',','.');const n=Number(value);if(n>0&&n<=10000000)totals.push(n);}
 }
 const unique=[...new Set(totals)];
 let date=null;
 for(const line of lines){const m=line.match(/\b(20\d{2})[-/](\d{2})[-/](\d{2})\b/);if(m){const iso=`${m[1]}-${m[2]}-${m[3]}`;if(!Number.isNaN(Date.parse(iso))&&new Date(iso).toISOString().slice(0,10)===iso){date=iso;break;}}}
 const merchant=lines.find(s=>/[a-z]{3}/i.test(s)&&!/^\s*(receipt|invoice|tax|vat|tel|phone|date|cashier)\b/i.test(s))?.slice(0,200)||'';
 return {merchant,amount:unique.length===1?unique[0]:null,expense_date:date,taxes:null,items:[],mode:'On-device OCR',message:'Text read on your device. Check the merchant, total, date, and split before saving. Ambiguous values are left blank.',ocr_text:lines.join('\n')};
}
