class VoiceCapture extends AudioWorkletProcessor {
 process(inputs,outputs){const channel=inputs[0]?.[0];if(channel)this.port.postMessage(new Float32Array(channel));for(const output of outputs)for(const c of output)c.fill(0);return true;}
}
registerProcessor('voice-capture',VoiceCapture);
