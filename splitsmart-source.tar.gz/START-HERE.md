# Complete JavaScript source

This folder includes the browser JavaScript, Node.js/Express backend, HTML/CSS, database SQL, dependency lockfile, tests, and deployment configuration. There is no TypeScript compilation step.

## Run locally

Install Node.js 24, extract this archive, open a terminal in this folder, then run:

```sh
npx --yes pnpm@11.25.0 install --frozen-lockfile
npm run setup
npm run db:init
npm test
npm start
```

Open http://localhost:3000 and create your account. Use a password of at least 12 characters. Local development has its own empty SQLite database and does not use the hosted database. The setup command creates fresh local secrets in `.env`.

The shared live app is https://splitsmart-bheejay01.onrender.com/. Its credentials remain in Render and are deliberately excluded from this download.

## Where to edit

- `public/app.js`: frontend screens and interactions.
- `public/styles.css` and `public/index.html`: styling and page shell.
- `server.js`: Express setup and startup.
- `routes/`: authentication, groups, invitations, expenses, payments, statements, receipts, and activity APIs.
- `services/`: split calculations, encryption, AI integration, and CSV parsing.
- `database/`: schema and local/Turso storage adapter.
- `middleware/`: request validation and authorization.
- `tests/`: 33 automated tests using isolated disposable databases.

No demonstration accounts, expenses, or bank transactions are included. Test fixtures exist only in the isolated test suite. Free on-device receipt OCR and camera capture work without a key. Conversational AI and recorded voice transcription require GEMINI_API_KEY from a free-tier project in Google AI Studio. Browser dictation and read-aloud depend on browser support. Live bank connections are not integrated; CSV statement imports are supported.

Read README.md for features and limitations, DEPLOYMENT.md for hosting, and VALIDATION.md for the checks completed. Passing tests cannot guarantee that software has no bugs.

## Payment proof verification update

Bank and mobile transfer claims require a JPG, PNG or PDF proof (up to 5 MB). Files and extracted details are accessible only to the sender and recipient. Sending documents to AI requires explicit consent. AI reads details and flags mismatched amounts, currencies and incomplete transfers; it never authenticates a document or settles a payment. AI outages fall back to recipient review. The receiver must check their account and confirm; pending, disputed and cancelled payments do not affect the ledger. Exact attached proof reuse is blocked for non-cancelled payments, but altered screenshots cannot be reliably detected. Receiver requests are in-app notifications, not email or SMS. Existing records are preserved.

Real my.t wallet movements remain unconnected pending the approved API documentation, credentials, and verified callback integration. Do not collect bank passwords or wallet PINs in SplitSmart. Official provider overview: https://www.myt.mu/money/business-solutions
