import './db.js';
console.log('SQLite schema initialized.');
