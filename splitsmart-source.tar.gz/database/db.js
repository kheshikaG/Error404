import {DatabaseSync} from 'node:sqlite';
import {AsyncLocalStorage} from 'node:async_hooks';
import {mkdirSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {createClient} from '@libsql/client/web';

export const remote = !!process.env.TURSO_DATABASE_URL;
if(process.env.NODE_ENV==='production'&&!remote)throw new Error('Production requires TURSO_DATABASE_URL; local files are not durable on free hosting.');
if(remote&&!process.env.TURSO_AUTH_TOKEN)throw new Error('TURSO_AUTH_TOKEN is required.');
if(remote&&!/^(libsql|https):\/\//.test(process.env.TURSO_DATABASE_URL))throw new Error('Use a secure Turso database URL.');
const path=process.env.DATABASE_PATH||'./data/splitsmart-live.sqlite';
if(!remote&&path!==':memory:')mkdirSync(dirname(resolve(path)),{recursive:true});
export const db=remote?createClient({url:process.env.TURSO_DATABASE_URL,authToken:process.env.TURSO_AUTH_TOKEN,intMode:'number'}):new DatabaseSync(path);
if(!remote)db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
const context=new AsyncLocalStorage();
let tail=Promise.resolve();
function exclusive(fn){const result=tail.then(fn);tail=result.catch(()=>{});return result;}
async function execute(sql,args=[]){
 const tx=context.getStore();
 const perform=async()=>{
  if(remote){const r=await(tx||db).execute({sql,args});return{rows:r.rows,changes:r.rowsAffected,lastInsertRowid:r.lastInsertRowid};}
  const statement=db.prepare(sql);
  if(/^\s*(SELECT|PRAGMA)/i.test(sql))return{rows:statement.all(...args)};
  return{...statement.run(...args),rows:[]};
 };
 // A local connection must not leak another request's query into an open transaction.
 return tx||remote?perform():exclusive(perform);
}
export const all=async(sql,...args)=>(await execute(sql,args)).rows;
export const get=async(sql,...args)=>(await all(sql,...args))[0];
export const run=async(sql,...args)=>execute(sql,args);
export async function batch(statements){
 const tx=context.getStore();
 if(remote){const results=await(tx||db).batch(statements);return results.map(r=>({rows:r.rows,changes:r.rowsAffected,lastInsertRowid:r.lastInsertRowid}));}
 return transaction(async()=>{const results=[];for(const s of statements)results.push(await execute(s.sql,s.args));return results;});
}
export async function transaction(fn){
 if(context.getStore())return fn();
 const perform=async()=>{
  const tx=remote?await db.transaction('write'):db;
  if(!remote)db.exec('BEGIN IMMEDIATE');
  try{const value=await context.run(tx,fn);if(remote)await tx.commit();else db.exec('COMMIT');return value;}
  catch(e){if(remote){try{await tx.rollback();}catch{}}else db.exec('ROLLBACK');throw e;}
  finally{if(remote)tx.close();}
 };
 return remote?perform():exclusive(perform);
}
export const audit=(uid,gid,action,detail='')=>run('INSERT INTO audit_logs(user_id,group_id,action,detail) VALUES(?,?,?,?)',uid,gid,action,detail);
export const notify=(uid,gid,message,pid=null)=>run('INSERT INTO notifications(user_id,group_id,message,payment_id) VALUES(?,?,?,?)',uid,gid,message,pid);
const schema=readFileSync(new URL('./schema.sql',import.meta.url),'utf8');
if(remote)await db.executeMultiple(schema);else db.exec(schema);
for(const name of ['Food','Transport','Accommodation','Shopping','Entertainment','Utilities','Rent','Education','Travel','Groceries','Health','Other'])await run('INSERT OR IGNORE INTO categories(name) VALUES(?)',name);
