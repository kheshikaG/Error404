PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'MUR', timezone TEXT NOT NULL DEFAULT 'Indian/Mauritius',
 photo TEXT, notifications_enabled INTEGER NOT NULL DEFAULT 1, mfa_enabled INTEGER NOT NULL DEFAULT 0,
 mfa_secret TEXT, mfa_pending TEXT, mfa_last_counter INTEGER NOT NULL DEFAULT -1,
 status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'MUR', created_by INTEGER NOT NULL REFERENCES users(id), archived INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS group_members (group_id INTEGER NOT NULL REFERENCES groups(id), user_id INTEGER NOT NULL REFERENCES users(id), role TEXT NOT NULL CHECK(role IN ('owner','admin','member')), PRIMARY KEY(group_id,user_id));
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), filename TEXT NOT NULL, mime TEXT NOT NULL, extracted_json TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS receipt_items(id INTEGER PRIMARY KEY, receipt_id INTEGER NOT NULL REFERENCES receipts(id), description TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 1, amount INTEGER NOT NULL CHECK(amount>=0));
CREATE TABLE IF NOT EXISTS expenses (
 id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL REFERENCES groups(id), created_by INTEGER NOT NULL REFERENCES users(id), description TEXT NOT NULL,
 amount INTEGER NOT NULL CHECK(amount>0), currency TEXT NOT NULL, category_id INTEGER REFERENCES categories(id), payer_id INTEGER NOT NULL REFERENCES users(id),
 payment_method TEXT NOT NULL, expense_date TEXT NOT NULL, receipt_id INTEGER REFERENCES receipts(id), notes TEXT NOT NULL DEFAULT '', split_type TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','deleted')), review_reason TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS expense_shares (id INTEGER PRIMARY KEY, expense_id INTEGER NOT NULL REFERENCES expenses(id), user_id INTEGER NOT NULL REFERENCES users(id), share_type TEXT NOT NULL, share_amount INTEGER NOT NULL CHECK(share_amount>=0), percentage REAL, status TEXT NOT NULL DEFAULT 'active', UNIQUE(expense_id,user_id));
CREATE TABLE IF NOT EXISTS expense_items (id INTEGER PRIMARY KEY, expense_id INTEGER NOT NULL REFERENCES expenses(id), description TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 1, amount INTEGER NOT NULL CHECK(amount>0), participants TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS cash_payments (
 id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL REFERENCES groups(id), sender_id INTEGER NOT NULL REFERENCES users(id), receiver_id INTEGER NOT NULL REFERENCES users(id),
 amount INTEGER NOT NULL CHECK(amount>0), currency TEXT NOT NULL, payment_method TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','disputed','cancelled')), claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, confirmed_at TEXT, disputed_at TEXT, notes TEXT NOT NULL DEFAULT '', CHECK(sender_id!=receiver_id)
);
CREATE TABLE IF NOT EXISTS settlements(id INTEGER PRIMARY KEY, payment_id INTEGER NOT NULL UNIQUE REFERENCES cash_payments(id), confirmed_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS bank_connections(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), provider TEXT NOT NULL DEFAULT 'Statement import', encrypted_token TEXT, status TEXT NOT NULL, permission TEXT NOT NULL DEFAULT 'read_only', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX IF NOT EXISTS bank_active ON bank_connections(user_id) WHERE status='connected';
CREATE TABLE IF NOT EXISTS bank_transactions(id INTEGER PRIMARY KEY, connection_id INTEGER NOT NULL REFERENCES bank_connections(id), merchant TEXT NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL, transaction_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS transaction_matches(id INTEGER PRIMARY KEY, transaction_id INTEGER NOT NULL UNIQUE REFERENCES bank_transactions(id), expense_id INTEGER NOT NULL UNIQUE REFERENCES expenses(id), user_id INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS bank_dismissals(transaction_id INTEGER NOT NULL REFERENCES bank_transactions(id), expense_id INTEGER NOT NULL REFERENCES expenses(id), user_id INTEGER NOT NULL REFERENCES users(id), PRIMARY KEY(transaction_id,expense_id,user_id));
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), group_id INTEGER REFERENCES groups(id), payment_id INTEGER REFERENCES cash_payments(id), message TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), group_id INTEGER REFERENCES groups(id), action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS trusted_devices(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), token_hash TEXT NOT NULL UNIQUE, expires_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS members_user ON group_members(user_id,group_id);
CREATE INDEX IF NOT EXISTS expenses_group_date ON expenses(group_id,expense_date);
CREATE INDEX IF NOT EXISTS shares_expense ON expense_shares(expense_id);
CREATE INDEX IF NOT EXISTS payments_group ON cash_payments(group_id,status);
CREATE INDEX IF NOT EXISTS notifications_user ON notifications(user_id,created_at);
CREATE INDEX IF NOT EXISTS audit_group ON audit_logs(group_id,id);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS group_invitations(id INTEGER PRIMARY KEY,group_id INTEGER NOT NULL REFERENCES groups(id),created_by INTEGER NOT NULL REFERENCES users(id),token_hash TEXT NOT NULL UNIQUE,expires_at INTEGER NOT NULL,used_by INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS bank_imports(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),content_hash TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,content_hash));
CREATE TABLE IF NOT EXISTS receipt_files(receipt_id INTEGER PRIMARY KEY REFERENCES receipts(id),content BLOB NOT NULL);

CREATE TABLE IF NOT EXISTS payment_proofs (
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), group_id INTEGER NOT NULL REFERENCES groups(id), receiver_id INTEGER NOT NULL REFERENCES users(id),
 amount INTEGER NOT NULL, currency TEXT NOT NULL, mime TEXT NOT NULL, content BLOB NOT NULL, content_hash TEXT NOT NULL, analysis_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS proof_digest ON payment_proofs(content_hash);
CREATE TABLE IF NOT EXISTS payment_proof_links(payment_id INTEGER PRIMARY KEY REFERENCES cash_payments(id), proof_id INTEGER NOT NULL UNIQUE REFERENCES payment_proofs(id));
