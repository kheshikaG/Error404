import {z,date,currency,assert} from '../middleware/validation.js';
// RFC-style quoted CSV fields, including escaped quotes and embedded newlines.
export function parseCSV(text){
 const rows=[];let row=[],value='',quoted=false,closed=false;
 text=text.replace(/^\uFEFF/,'');
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'&&text[i+1]==='"'){value+='"';i++;}else if(c==='"'){quoted=false;closed=true;}else value+=c;continue;}
  if(c==='"'){assert(!value&&!closed,'Invalid CSV quoting.');quoted=true;continue;}
  if(c===','||c==='\n'||c==='\r'){row.push(value);value='';closed=false;if(c!==','){if(row.some(v=>v.trim()))rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}continue;}
  assert(!closed,'Unexpected text after a quoted CSV field.');value+=c;
 }
 assert(!quoted,'Unclosed CSV quote.');row.push(value);if(row.some(v=>v.trim()))rows.push(row);return rows;
}
export function parseStatement(text){
 assert(typeof text==='string'&&Buffer.byteLength(text)<=200000,'Statement must be smaller than 200 KB.');
 const [head,...rows]=parseCSV(text);assert(head&&rows.length,'The CSV must include a header and at least one transaction.');
 const fields=head.map(v=>v.trim().toLowerCase());assert(new Set(fields).size===fields.length,'CSV headers must be unique.');
 for(const name of ['date','merchant','amount','currency'])assert(fields.includes(name),`Missing CSV column: ${name}.`);
 assert(rows.length<=1000,'Import at most 1,000 transactions at a time.');
 return rows.map((r,i)=>{
  assert(r.length===fields.length,`Row ${i+2} has the wrong number of columns.`);
  const d=Object.fromEntries(fields.map((f,j)=>[f,r[j].trim()]));
  assert(/^-?\d+(\.\d{1,2})?$/.test(d.amount),`Row ${i+2}: amount must be a number with at most two decimals. Use negative amounts for purchases.`);
  const amount=Math.round(Number(d.amount)*100);assert(Number.isSafeInteger(amount)&&amount!==0&&Math.abs(amount)<=1e9,`Row ${i+2}: amount is invalid.`);
  return{transaction_date:date.parse(d.date),merchant:z.string().min(1).max(200).parse(d.merchant),amount,currency:currency.parse(d.currency.toUpperCase())};
 });
}
