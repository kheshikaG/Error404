import { all, get } from '../database/db.js';
import { assert } from '../middleware/validation.js';
export const cents = n => Math.round(n * 100);
function allocate(total, weights) {
  const sum = weights.reduce((a, b) => a + b, 0);
  assert(sum > 0, 'Select at least one participant.');
  const raw = weights.map(w => total * w / sum);
  const result = raw.map(Math.floor);
  let remaining = total - result.reduce((a, b) => a + b, 0);
  const order = raw.map((v, i) => ({
    i,
    f: v - result[i]
  })).sort((a, b) => b.f - a.f || a.i - b.i);
  for (let i = 0; i < remaining; i++) result[order[i % order.length].i]++;
  return result;
}
export function splitExpense(e) {
  const total = cents(e.amount),
    p = e.participants;
  let shares;
  if (e.split_type === 'equal') shares = allocate(total, p.map(() => 1));
  if (e.split_type === 'percentage') {
    assert(e.values.length === p.length && Math.abs(e.values.reduce((a, b) => a + b, 0) - 100) < 0.000001, 'Percentages must total 100.');
    shares = allocate(total, e.values);
  }
  if (e.split_type === 'exact') {
    assert(e.values.length === p.length, 'Enter an amount for each participant.');
    assert(e.values.every(v => Math.abs(v * 100 - cents(v)) < 0.000001), 'Shares must use at most two decimal places.');
    shares = e.values.map(cents);
    assert(shares.reduce((a, b) => a + b, 0) === total, 'Shares must equal the expense total.');
  }
  if (e.split_type === 'items') {
    assert(e.items.length > 0, 'Add at least one item.');
    shares = p.map(() => 0);
    let sum = 0;
    for (const item of e.items) {
      assert(item.participants.every(uid => p.includes(uid)), 'Item assignees must be selected participants.');
      const itemTotal = cents(item.amount);
      sum += itemTotal;
      const amounts = allocate(itemTotal, item.participants.map(() => 1));
      item.participants.forEach((uid, i) => shares[p.indexOf(uid)] += amounts[i]);
    }
    assert(sum === total, 'Item totals (including shared tax) must equal the expense total.');
  }
  return p.map((uid, i) => ({
    user_id: uid,
    amount: shares[i]
  }));
}
export async function balances(gid) {
  const members = await all('SELECT u.id,u.name FROM users u JOIN group_members m ON m.user_id=u.id WHERE m.group_id=?', gid);
  const currency = (await get('SELECT currency FROM groups WHERE id=?', gid)).currency;
  const map = new Map(members.map(m => [m.id, {
    ...m,
    paid: 0,
    share: 0,
    net: 0
  }]));
  const expenses = await all('SELECT * FROM expenses WHERE group_id=? AND status=?', gid, 'active');
  for (const e of expenses) {
    if (map.has(e.payer_id)) {
      map.get(e.payer_id).paid += e.amount;
      map.get(e.payer_id).net += e.amount;
    }
    for (const s of await all('SELECT * FROM expense_shares WHERE expense_id=?', e.id)) {
      if (map.has(s.user_id)) {
        map.get(s.user_id).share += s.share_amount;
        map.get(s.user_id).net -= s.share_amount;
      }
    }
  }
  for (const p of await all('SELECT * FROM cash_payments WHERE group_id=? AND status=?', gid, 'confirmed')) {
    if (map.has(p.sender_id)) map.get(p.sender_id).net += p.amount;
    if (map.has(p.receiver_id)) map.get(p.receiver_id).net -= p.amount;
  }
  return {
    currency,
    total: expenses.reduce((s, e) => s + e.amount, 0),
    members: [...map.values()]
  };
}
export function settlements(members) {
  const debt = members.filter(m => m.net < 0).map(m => ({
    ...m,
    left: -m.net
  })).sort((a, b) => b.left - a.left);
  const credit = members.filter(m => m.net > 0).map(m => ({
    ...m,
    left: m.net
  })).sort((a, b) => b.left - a.left);
  const result = [];
  let i = 0,
    j = 0;
  while (i < debt.length && j < credit.length) {
    const amount = Math.min(debt[i].left, credit[j].left);
    result.push({
      sender_id: debt[i].id,
      sender: debt[i].name,
      receiver_id: credit[j].id,
      receiver: credit[j].name,
      amount
    });
    debt[i].left -= amount;
    credit[j].left -= amount;
    if (!debt[i].left) i++;
    if (!credit[j].left) j++;
  }
  return result;
}
export async function detectDuplicate(gid, e, exclude = 0) {
  return await all('SELECT id,description,amount,expense_date FROM expenses WHERE group_id=? AND amount=? AND currency=? AND expense_date=? AND payer_id=? AND status=? AND id!=?', gid, cents(e.amount), e.currency, e.expense_date, e.payer_id, 'active', exclude);
}
export function matchBankTransaction(e, t) {
  if (e.currency !== t.currency) return 0;
  const amount = e.amount === Math.abs(t.amount) ? 0.65 : 0;
  const days = Math.abs(Date.parse(e.expense_date) - Date.parse(t.transaction_date)) / 86400000;
  const date = days <= 1 ? 0.25 : days <= 3 ? 0.1 : 0;
  const words = e.description.toLowerCase().split(/\W+/);
  return amount + date + (words.some(w => w.length > 2 && t.merchant.toLowerCase().includes(w)) ? 0.1 : 0);
}
