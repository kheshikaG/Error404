# Validation

All 23 integration tests passed after the asynchronous database conversion. These cover real account creation, sessions, origin protection, group/expense authorization, four split methods, balances, claim/confirm/dispute/cancel, import previews and deduplication, matching ownership, missing-AI configuration, invitations, CSV validation, encryption/TOTP primitives, rate limits, an empty initial database, protected receipt storage, transaction rollback, and concurrent confirmation without double credit.

The suite uses an in-memory SQLite database with disposable test fixtures. These are never seeded into the application. Run `npm test`.

Production uses Turso over HTTPS, while local tests exercise the same async API with the SQLite adapter. On 24 September 2026, Render reported a successful live deployment at https://splitsmart-bheejay01.onrender.com/. The login and registration pages rendered, and an invalid login returned the expected database-backed authentication error. No test accounts were created in production. The 23 local tests and all JavaScript syntax checks were repeated successfully for this source delivery. Authenticated production workflows and live AI calls have not been fully verified by the agent.

No claim is made that live banking, email recovery, MFA recovery, penetration testing, formal accessibility certification, or production load testing is complete. See README.md and DEPLOYMENT.md for current boundaries.


## Version 1.2 validation

33 automated tests pass, including OCR total ambiguity, real-provider request adapters tested with isolated HTTP stubs, quota/key failures, unknown-member rejection, cloud receipt consent, no ledger mutation during OCR, and camera-track cleanup. Provider stubs are used only in tests, never in the app.

A generated receipt image was uploaded through the local browser UI and actual Tesseract OCR extracted CAFE CENTRAL, 2026-09-24, and 172.50. No simulated recognition output was used. The actual device camera/microphone and live Gemini requests require device permissions and a configured provider key and have not yet been verified by the agent.

## Payment proof verification update

Bank and mobile transfer claims require a JPG, PNG or PDF proof (up to 5 MB). Files and extracted details are accessible only to the sender and recipient. Sending documents to AI requires explicit consent. AI reads details and flags mismatched amounts, currencies and incomplete transfers; it never authenticates a document or settles a payment. AI outages fall back to recipient review. The receiver must check their account and confirm; pending, disputed and cancelled payments do not affect the ledger. Exact attached proof reuse is blocked for non-cancelled payments, but altered screenshots cannot be reliably detected. Receiver requests are in-app notifications, not email or SMS. Existing records are preserved.

Real my.t wallet movements remain unconnected pending the approved API documentation, credentials, and verified callback integration. Do not collect bank passwords or wallet PINs in SplitSmart. Official provider overview: https://www.myt.mu/money/business-solutions

Verification: all 33 tests passed. Local browser test selected Bank transfer, uploaded a synthetic PNG, created a pending claim and displayed the private review/download panel. No real transfer was performed.
