delete process.env.GEMINI_API_KEY;
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
process.env.DATABASE_PATH = ':memory:';
delete process.env.TURSO_DATABASE_URL;
delete process.env.TURSO_AUTH_TOKEN;
process.env.NODE_ENV='test';
process.env.SESSION_SECRET = randomBytes(32).toString('hex');
process.env.ENCRYPTION_KEY = randomBytes(32).toString('hex');
process.env.APP_ORIGIN = 'http://localhost:3000';
delete process.env.AI_API_KEY;
const {
  app
} = await import('../server.js');
const {
  all,
  get,
  run
} = await import('../database/db.js');
const {
  splitExpense,
  settlements
} = await import('../services/finance.js');
const {
  validateDraft,
  parseExpense
} = await import('../services/ai.js');
const {
  encrypt,
  decrypt,
  totp,
  verifyTotp
} = await import('../services/encryption.js');
const server = app.listen(0, '127.0.0.1');
await new Promise(r => server.once('listening', r));
const base = `http://127.0.0.1:${server.address().port}/api`;
after(() => server.close());
const password = randomBytes(20).toString('hex');
async function call(path, method = 'GET', body, cookie = '', headers = {}) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-SplitSmart': '1',
      Cookie: cookie,
      ...headers
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const data = await r.json();
  return {
    status: r.status,
    data,
    cookie: r.headers.get('set-cookie')?.split(';')[0],
    headers: r.headers
  };
}
let alice, bob, outsider, gid, eid, pid;
test('registration, password hashing, cookie flags, duplicate email', async () => {
  alice = await call('/auth/register', 'POST', {
    name: 'Alice',
    email: 'alice@test.local',
    password
  });
  bob = await call('/auth/register', 'POST', {
    name: 'Bob',
    email: 'bob@test.local',
    password
  });
  outsider = await call('/auth/register', 'POST', {
    name: 'Other',
    email: 'other@test.local',
    password
  });
  assert.equal(alice.status, 201);
  assert.match(alice.headers.get('set-cookie'), /HttpOnly/);
  assert.match(alice.headers.get('set-cookie'), /SameSite=Strict/);
  assert.notEqual((await get('SELECT password_hash FROM users WHERE id=?', alice.data.id)).password_hash, password);
  assert.equal((await call('/auth/register', 'POST', {
    name: 'A',
    email: 'alice@test.local',
    password
  })).status, 400);
});
test('login succeeds, invalid password and injection login fail', async () => {
  assert.equal((await call('/auth/login', 'POST', {
    email: 'alice@test.local',
    password
  })).status, 200);
  assert.equal((await call('/auth/login', 'POST', {
    email: 'alice@test.local',
    password: 'wrong'
  })).status, 401);
  assert.equal((await call('/auth/login', 'POST', {
    email: "' OR 1=1 --",
    password
  })).status, 401);
});
test('invalid, missing and expired sessions rejected', async () => {
  assert.equal((await call('/me')).status, 401);
  assert.equal((await call('/me', 'GET', undefined, 'ss_session=forged.jwt')).status, 401);
  const login = await call('/auth/login', 'POST', {
    email: 'alice@test.local',
    password
  });
  const {
    tokenHash
  } = await import('../middleware/auth.js');
  await run('UPDATE sessions SET expires_at=0 WHERE token_hash=?', tokenHash(login.cookie.split('=')[1]));
  assert.equal((await call('/me', 'GET', undefined, login.cookie)).status, 401);
});
test('CSRF origin and custom header protection', async () => {
  assert.equal((await call('/groups', 'POST', {
    name: 'bad',
    currency: 'MUR'
  }, alice.cookie, {
    Origin: 'https://evil.example'
  })).status, 403);
  assert.equal((await call('/groups', 'POST', {
    name: 'bad',
    currency: 'MUR'
  }, alice.cookie, {
    'X-SplitSmart': ''
  })).status, 403);
});
test('group creation and member addition; unauthorized access blocked', async () => {
  const r = await call('/groups', 'POST', {
    name: 'Friends',
    currency: 'MUR'
  }, alice.cookie);
  assert.equal(r.status, 201);
  gid = r.data.id;
  assert.equal((await call(`/groups/${gid}/members`, 'POST', {
    email: 'bob@test.local'
  }, alice.cookie)).status, 201);
  assert.equal((await call(`/groups/${gid}`, 'GET', undefined, outsider.cookie)).status, 403);
  assert.equal((await call(`/groups/${gid}/expenses`, 'GET', undefined, outsider.cookie)).status, 403);
  assert.equal((await call(`/groups/${gid}/members`, 'POST', {
    email: 'other@test.local'
  }, bob.cookie)).status, 403);
});
function expense(extra = {}) {
  return {
    description: 'Pizza',
    amount: 1200,
    currency: 'MUR',
    payer_id: alice.data.id,
    participants: [alice.data.id, bob.data.id],
    split_type: 'equal',
    category: 'Food',
    expense_date: new Date().toISOString().slice(0, 10),
    payment_method: 'Cash',
    ...extra
  };
}
test('equal split preserves cents; percentage, exact and item splits', () => {
  assert.deepEqual(splitExpense({
    amount: 10,
    participants: [1, 2, 3],
    split_type: 'equal'
  }).map(s => s.amount), [334, 333, 333]);
  assert.deepEqual(splitExpense({
    amount: 10,
    participants: [1, 2],
    split_type: 'percentage',
    values: [25, 75]
  }).map(s => s.amount), [250, 750]);
  assert.deepEqual(splitExpense({
    amount: 10,
    participants: [1, 2],
    split_type: 'exact',
    values: [2, 8]
  }).map(s => s.amount), [200, 800]);
  assert.deepEqual(splitExpense({
    amount: 10,
    participants: [1, 2],
    split_type: 'items',
    items: [{
      amount: 9,
      participants: [1, 2]
    }, {
      amount: 1,
      participants: [2]
    }]
  }).map(s => s.amount), [450, 550]);
  assert.throws(() => splitExpense({
    amount: 10,
    participants: [1, 2],
    split_type: 'percentage',
    values: [30, 30]
  }));
  assert.throws(() => splitExpense({
    amount: 10,
    participants: [1, 2],
    split_type: 'exact',
    values: [2, 3]
  }));
});
test('expense preview does not write; save creates shares and balances', async () => {
  assert.equal((await call(`/groups/${gid}/expenses/preview`, 'POST', expense(), alice.cookie)).status, 200);
  assert.equal((await get('SELECT count(*) AS n FROM expenses')).n, 0);
  const r = await call(`/groups/${gid}/expenses`, 'POST', expense(), alice.cookie);
  assert.equal(r.status, 201);
  eid = r.data.id;
  assert.equal((await get('SELECT sum(share_amount) AS n FROM expense_shares WHERE expense_id=?', eid)).n, 120000);
  const b = await call(`/groups/${gid}/balances`, 'GET', undefined, alice.cookie);
  assert.deepEqual(b.data.members.map(m => m.net), [60000, -60000]);
});
test('negative amounts, invalid dates, invalid users, wrong currency and shares rejected', async () => {
  for (const change of [{
    amount: -1
  }, {
    amount: 0
  }, {
    amount: 1.001
  }, {
    payer_id: 999999
  }, {
    participants: [alice.data.id, 999999]
  }, {
    participants: [alice.data.id, alice.data.id]
  }, {
    currency: 'USD'
  }, {
    expense_date: '2026-02-30'
  }, {
    split_type: 'exact',
    values: [1, 2]
  }]) {
    const r = await call(`/groups/${gid}/expenses`, 'POST', expense(change), alice.cookie);
    assert.ok([400, 403].includes(r.status), JSON.stringify(change));
  }
});
test('expense ownership enforced; SQL injection stored safely; duplication requires confirmation', async () => {
  assert.equal((await call('/expenses/' + eid, 'PUT', expense(), bob.cookie)).status, 403);
  assert.equal((await call('/expenses/' + eid, 'DELETE', undefined, outsider.cookie)).status, 403);
  assert.equal((await call(`/groups/${gid}/expenses`, 'POST', expense({
    description: 'Dinner'
  }), alice.cookie)).status, 409);
  const r = await call(`/groups/${gid}/expenses`, 'POST', expense({
    description: "'; DROP TABLE users; --",
    amount: 10
  }), alice.cookie);
  assert.equal(r.status, 201);
  assert.equal((await get('SELECT count(*) AS n FROM users')).n, 3);
  await call('/expenses/' + r.data.id, 'DELETE', {}, alice.cookie);
});
test('payment is pending and does not alter balance; forged confirmation blocked', async () => {
  const r = await call('/payments/cash', 'POST', {
    group_id: gid,
    receiver_id: alice.data.id,
    amount: 500,
    currency: 'MUR',
    payment_method: 'Cash'
  }, bob.cookie);
  assert.equal(r.status, 201);
  pid = r.data.id;
  assert.equal((await call(`/groups/${gid}/balances`, 'GET', undefined, alice.cookie)).data.members[0].net, 60000);
  assert.equal((await call(`/payments/${pid}/confirm`, 'POST', {}, bob.cookie)).status, 403);
  assert.equal((await call(`/payments/${pid}/confirm`, 'POST', {}, outsider.cookie)).status, 403);
});
test('receiver confirmation changes balance once, with audit and settlement', async () => {
  assert.equal((await call(`/payments/${pid}/confirm`, 'POST', {}, alice.cookie)).status, 200);
  assert.equal((await call(`/groups/${gid}/balances`, 'GET', undefined, alice.cookie)).data.members[0].net, 10000);
  assert.equal((await call(`/payments/${pid}/confirm`, 'POST', {}, alice.cookie)).status, 409);
  assert.equal((await get('SELECT count(*) AS n FROM settlements WHERE payment_id=?', pid)).n, 1);
});
test('dispute and cancellation do not settle', async () => {
  for (const action of ['dispute', 'cancel']) {
    const p = await call('/payments/cash', 'POST', {
      group_id: gid,
      receiver_id: alice.data.id,
      amount: 50,
      currency: 'MUR',
      payment_method: 'Cash'
    }, bob.cookie);
    assert.equal((await call(`/payments/${p.data.id}/${action}`, 'POST', {}, action === 'dispute' ? alice.cookie : bob.cookie)).status, 200);
  }
  assert.equal((await call(`/groups/${gid}/balances`, 'GET', undefined, alice.cookie)).data.members[0].net, 10000);
});
test('notifications private and group roles cannot be forged', async () => {
  const n = (await call('/notifications', 'GET', undefined, alice.cookie)).data[0];
  assert.equal((await call(`/notifications/${n.id}/read`, 'POST', {}, outsider.cookie)).status, 404);
  assert.equal((await call(`/groups/${gid}/members/${alice.data.id}`, 'PUT', {
    role: 'admin'
  }, bob.cookie)).status, 403);
});
test('real statement import and matching enforce review, ownership, uniqueness and revocation', async () => {
  const csv = 'date,merchant,amount,currency\n' + new Date().toISOString().slice(0, 10) + ',Restaurant,-1200.00,MUR';
  assert.equal((await call('/bank/mock-connect', 'POST', {
    consent: true
  }, alice.cookie)).status, 404);
  assert.equal((await call('/bank/import/preview', 'POST', {
    csv
  }, alice.cookie)).data.transactions.length, 1);
  assert.equal((await get('SELECT count(*) AS n FROM bank_transactions')).n, 0);
  assert.equal((await call('/bank/import', 'POST', {
    csv
  }, alice.cookie)).status, 400);
  assert.equal((await call('/bank/import', 'POST', {
    csv,
    confirmed: true
  }, alice.cookie)).status, 201);
  assert.equal((await call('/bank/import', 'POST', {
    csv,
    confirmed: true
  }, alice.cookie)).status, 409);
  const b = await call('/bank/transactions', 'GET', undefined, alice.cookie);
  const t = b.data.transactions.find(t => t.amount === -120000);
  assert.ok(t.suggestions.some(s => s.id === eid));
  assert.equal((await call('/bank/match', 'POST', {
    transaction_id: t.id,
    expense_id: eid
  }, outsider.cookie)).status, 403);
  assert.equal((await call('/bank/match', 'POST', {
    transaction_id: t.id,
    expense_id: eid
  }, alice.cookie)).status, 200);
  assert.equal((await call('/bank/match', 'POST', {
    transaction_id: t.id,
    expense_id: eid
  }, alice.cookie)).status, 409);
  assert.equal((await call('/expenses/' + eid, 'PUT', expense(), alice.cookie)).status, 400);
  await call('/bank/disconnect', 'POST', {}, alice.cookie);
  assert.equal((await get('SELECT encrypted_token FROM bank_connections WHERE user_id=?', alice.data.id)).encrypted_token, null);
  assert.equal((await call('/bank/transactions', 'GET', undefined, alice.cookie)).data.connection, null);
});
test('AI requires a real provider and invalid drafts cannot write ledger', async () => {
  const context = {
    user: alice.data,
    members: [alice.data, bob.data],
    currency: 'MUR',
    today: '2026-09-23'
  };
  const count = (await get('SELECT count(*) AS n FROM expenses')).n;
  await assert.rejects(() => parseExpense('I paid 500 for lunch with Bob', context), /not connected/);
  const response = await call('/ai/parse-expense', 'POST', {
    group_id: gid,
    text: 'I paid 500 for lunch'
  }, alice.cookie);
  assert.equal(response.status, 503);
  assert.match(response.data.error, /not connected/);
  const d = {
    description: 'Lunch',
    amount: null,
    currency: 'MUR',
    participants: [alice.data.id, bob.data.id],
    payer_id: alice.data.id,
    expense_date: '2026-09-23',
    category: 'Food',
    confidence: 0.4,
    questions: []
  };
  assert.ok(validateDraft(d, context.members).questions.includes('What was the total amount?'));
  assert.throws(() => validateDraft({
    ...d,
    participants: [999999]
  }, context.members));
  assert.throws(() => validateDraft({
    ...d,
    amount: -10
  }, context.members));
  assert.equal((await get('SELECT count(*) AS n FROM expenses')).n, count);
});
test('single-use team invitations require consent and respect expiry', async () => {
  const result = await call(`/groups/${gid}/invitations`, 'POST', {}, alice.cookie);
  assert.equal(result.status, 201);
  const token = result.data.url.split('#invite=')[1];
  assert.equal((await call('/invitations/inspect', 'POST', {
    token
  }, outsider.cookie)).data.name, 'Friends');
  assert.equal((await call(`/groups/${gid}`, 'GET', undefined, outsider.cookie)).status, 403);
  assert.equal((await call('/invitations/accept', 'POST', {
    token
  }, outsider.cookie)).status, 200);
  assert.equal((await call('/invitations/accept', 'POST', {
    token
  }, outsider.cookie)).status, 404);
  assert.equal((await call(`/groups/${gid}`, 'GET', undefined, outsider.cookie)).status, 200);
  const expired = await call(`/groups/${gid}/invitations`, 'POST', {}, alice.cookie);
  await run('UPDATE group_invitations SET expires_at=0 WHERE used_by IS NULL');
  assert.equal((await call('/invitations/inspect', 'POST', {
    token: expired.data.url.split('#invite=')[1]
  }, bob.cookie)).status, 404);
  assert.equal((await call(`/groups/${gid}/invitations`, 'POST', {}, bob.cookie)).status, 403);
});
test('statement CSV rejects invalid rows and handles quoted descriptions', async () => {
  const {
    parseStatement
  } = await import('../services/statements.js');
  assert.equal(parseStatement('date,merchant,amount,currency\n2026-09-24,"Cafe, Central",-12.30,MUR')[0].merchant, 'Cafe, Central');
  assert.throws(() => parseStatement('date,merchant,amount,currency\n2026-02-30,Shop,-1,MUR'));
  assert.throws(() => parseStatement('date,merchant,amount,currency\n2026-09-24,Shop,1.234,MUR'));
  assert.throws(() => parseStatement('date,merchant,amount,currency\n2026-09-24,Shop,0,MUR'));
  assert.throws(() => parseStatement('date,merchant,amount,currency\n2026-09-24,"Unclosed,-1,MUR'));
});
test('settlement preserves net positions and encryption/TOTP roundtrip', () => {
  const members = [{
    id: 1,
    name: 'A',
    net: -500
  }, {
    id: 2,
    name: 'B',
    net: 300
  }, {
    id: 3,
    name: 'C',
    net: 200
  }];
  const s = settlements(members);
  const remaining = new Map(members.map(m => [m.id, m.net]));
  for (const p of s) {
    remaining.set(p.sender_id, remaining.get(p.sender_id) + p.amount);
    remaining.set(p.receiver_id, remaining.get(p.receiver_id) - p.amount);
  }
  assert.ok([...remaining.values()].every(v => v === 0));
  const secret = randomBytes(20).toString('hex');
  assert.equal(decrypt(encrypt(secret)), secret);
  const code = totp(secret);
  const c = verifyTotp(secret, code);
  assert.ok(c >= 0);
  assert.equal(verifyTotp(secret, code, c), -1);
});
test('login rate limit returns user-friendly 429', async () => {
  let r;
  for (let i = 0; i < 25; i++) r = await call('/auth/login', 'POST', {
    email: 'nobody@test.local',
    password: 'bad'
  });
  assert.equal(r.status, 429);
  assert.match(r.data.error, /Too many/);
});
