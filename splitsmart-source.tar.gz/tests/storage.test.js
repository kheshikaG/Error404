delete process.env.GEMINI_API_KEY;
import {test,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes} from 'node:crypto';
process.env.DATABASE_PATH=':memory:';
process.env.NODE_ENV='test';
delete process.env.TURSO_DATABASE_URL;
delete process.env.TURSO_AUTH_TOKEN;
delete process.env.AI_API_KEY;
process.env.SESSION_SECRET=randomBytes(32).toString('hex');
process.env.ENCRYPTION_KEY=randomBytes(32).toString('hex');
process.env.APP_ORIGIN='http://localhost:3000';
const {app}=await import('../server.js');
const {get,run,batch,transaction}=await import('../database/db.js');
const server=app.listen(0,'127.0.0.1');
await new Promise(r=>server.once('listening',r));
after(()=>server.close());
const base=`http://127.0.0.1:${server.address().port}/api`;
async function request(path,body,cookie=''){const r=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','X-SplitSmart':'1',Cookie:cookie},body:JSON.stringify(body)});return{status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
let owner,other;
test('fresh deployment database has no preloaded accounts or expenses',async()=>{
 assert.equal((await get('SELECT count(*) AS n FROM users')).n,0);
 assert.equal((await get('SELECT count(*) AS n FROM expenses')).n,0);
 const password=randomBytes(20).toString('hex');
 owner=await request('/auth/register',{name:'Owner',email:'owner@tests.local',password});
 other=await request('/auth/register',{name:'Other',email:'other@tests.local',password});
 assert.equal(owner.status,201);assert.equal(other.status,201);
});
test('receipt bytes persist in database and require owner or group access',async()=>{
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5N8AAAAASUVORK5CYII=','base64');
 const form=new FormData();form.append('receipt',new Blob([png],{type:'image/png'}),'receipt.png');
 const r=await fetch(base+'/receipts/upload',{method:'POST',headers:{'X-SplitSmart':'1',Cookie:owner.cookie},body:form});
 assert.equal(r.status,201);const receipt=await r.json();
 assert.match(receipt.message,/Enter the details manually/);
 const saved=await get('SELECT content FROM receipt_files WHERE receipt_id=?',receipt.id);
 assert.deepEqual(Buffer.from(saved.content),png);
 const read=await fetch(base+'/receipts/'+receipt.id,{headers:{Cookie:owner.cookie}});
 assert.equal(read.status,200);assert.deepEqual(Buffer.from(await read.arrayBuffer()),png);
 const denied=await fetch(base+'/receipts/'+receipt.id,{headers:{Cookie:other.cookie}});assert.equal(denied.status,403);
});
test('async transaction rolls back all batched writes on failure',async()=>{
 const original=(await get('SELECT name FROM users WHERE id=?',owner.data.id)).name;
 await assert.rejects(()=>transaction(async()=>{
  await batch([{sql:'UPDATE users SET name=? WHERE id=?',args:['Temporary',owner.data.id]},{sql:'UPDATE users SET name=? WHERE id=?',args:['Temporary',other.data.id]}]);
  throw new Error('force rollback');
 }),/force rollback/);
 assert.equal((await get('SELECT name FROM users WHERE id=?',owner.data.id)).name,original);
 assert.equal((await get('SELECT name FROM users WHERE id=?',other.data.id)).name,'Other');
});

test('receipt OCR drafts remain separate from expenses and cloud extraction requires consent',async()=>{
 const before=(await get('SELECT count(*) AS n FROM expenses')).n;
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5N8AAAAASUVORK5CYII=','base64');
 const form=new FormData();form.append('receipt',new Blob([png],{type:'image/png'}),'receipt.png');form.append('extraction','local');form.append('ocr_text','SHOP\nTOTAL 75.50');
 const r=await fetch(base+'/receipts/upload',{method:'POST',headers:{'X-SplitSmart':'1',Cookie:owner.cookie},body:form});assert.equal(r.status,201);assert.equal((await r.json()).amount,75.5);
 assert.equal((await get('SELECT count(*) AS n FROM expenses')).n,before);
 process.env.GEMINI_API_KEY='test-only-key';
 try{const cloud=new FormData();cloud.append('receipt',new Blob([png],{type:'image/png'}),'receipt.png');cloud.append('extraction','cloud');const denied=await fetch(base+'/receipts/upload',{method:'POST',headers:{'X-SplitSmart':'1',Cookie:owner.cookie},body:cloud});assert.equal(denied.status,400);}finally{delete process.env.GEMINI_API_KEY;}
 const deniedChat=await request('/ai/chat',{group_id:99999,messages:[{role:'user',content:'Hello'}]},owner.cookie);assert.equal(deniedChat.status,403);
});
test('parallel confirmation credits exactly once',async()=>{
 const g=await request('/groups',{name:'Concurrent group',currency:'MUR'},owner.cookie);
 await request(`/groups/${g.data.id}/members`,{email:'other@tests.local'},owner.cookie);
 const p=await request('/payments/cash',{group_id:g.data.id,receiver_id:owner.data.id,amount:10,currency:'MUR',payment_method:'Cash'},other.cookie);
 const results=await Promise.all([request(`/payments/${p.data.id}/confirm`,{},owner.cookie),request(`/payments/${p.data.id}/confirm`,{},owner.cookie)]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
 assert.equal((await get('SELECT count(*) AS n FROM settlements WHERE payment_id=?',p.data.id)).n,1);
});

test('transfer proofs require ownership, matching claim, recipient verification and prevent reuse',async()=>{
 const group=await request('/groups',{name:'Proof review',currency:'MUR'},owner.cookie);const gid=group.data.id;
 await request(`/groups/${gid}/members`,{email:'other@tests.local'},owner.cookie);
 const claim={group_id:gid,receiver_id:other.data.id,amount:12,currency:'MUR',payment_method:'Bank transfer'};
 assert.equal((await request('/payments/cash',claim,owner.cookie)).status,400);
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5N8AAAAASUVORK5CYII=','base64');
 const form=new FormData();form.append('proof',new Blob([png],{type:'image/png'}),'proof.png');
 for(const key of ['group_id','receiver_id','amount','currency'])form.append(key,claim[key]);
 const upload=await fetch(base+'/payments/proofs',{method:'POST',headers:{'X-SplitSmart':'1',Cookie:owner.cookie},body:form});
 assert.equal(upload.status,201);const proof=await upload.json();assert.equal(proof.analysis.status,'manual_review');
 assert.equal((await request('/payments/cash',{...claim,amount:13,proof_id:proof.id},owner.cookie)).status,400);
 assert.equal((await request('/payments/cash',{...claim,receiver_id:owner.data.id,proof_id:proof.id},other.cookie)).status,400);
 const payment=await request('/payments/cash',{...claim,proof_id:proof.id},owner.cookie);assert.equal(payment.status,201);
 assert.equal((await get('SELECT count(*) AS n FROM settlements WHERE payment_id=?',payment.data.id)).n,0);
 assert.equal((await request('/payments/cash',{...claim,proof_id:proof.id},owner.cookie)).status,409);
 assert.equal((await request(`/payments/${payment.data.id}/confirm`,{},owner.cookie)).status,403);
 const outsider=await request('/auth/register',{name:'Observer',email:'observer@tests.local',password:randomBytes(20).toString('hex')});
 await request(`/groups/${gid}/members`,{email:'observer@tests.local'},owner.cookie);
 assert.equal((await fetch(base+`/payments/${payment.data.id}/proof/file`,{headers:{Cookie:outsider.cookie}})).status,404);
 const file=await fetch(base+`/payments/${payment.data.id}/proof/file`,{headers:{Cookie:other.cookie}});assert.equal(file.status,200);assert.deepEqual(Buffer.from(await file.arrayBuffer()),png);
 const summary=await fetch(base+`/payments/${payment.data.id}/proof`,{headers:{Cookie:other.cookie}});assert.equal(summary.status,200);
 const confirms=await Promise.all([request(`/payments/${payment.data.id}/confirm`,{},other.cookie),request(`/payments/${payment.data.id}/confirm`,{},other.cookie)]);assert.deepEqual(confirms.map(r=>r.status).sort(),[200,409]);
 assert.equal((await get('SELECT count(*) AS n FROM settlements WHERE payment_id=?',payment.data.id)).n,1);
});
