import {test} from 'node:test';
import assert from 'node:assert/strict';
import {startCamera,stopCamera} from '../public/media.js';
test('camera stream is released when preview closes',async()=>{
 let stops=0;const stream={getTracks:()=>[{stop:()=>stops++}]};Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>stream}});
 const video={isConnected:true,closest:()=>({open:true}),play:async()=>{},hidden:true};await startCamera(video);assert.equal(video.srcObject,stream);assert.equal(video.hidden,false);stopCamera();assert.equal(stops,1);
});
test('camera permission resolving after dialog close does not keep the camera running',async()=>{
 let stops=0;Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>({getTracks:()=>[{stop:()=>stops++}]})}});
 await startCamera({isConnected:true,closest:()=>({open:false})});assert.equal(stops,1);
});
