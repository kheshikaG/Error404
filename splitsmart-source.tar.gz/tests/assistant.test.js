import {test,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {receiptFromText} from '../public/receipt-text.js';
import {parseExpense,chatAssistant,extractReceipt,transcribeAudio} from '../services/ai.js';
const originalFetch=globalThis.fetch;
afterEach(()=>{globalThis.fetch=originalFetch;delete process.env.GEMINI_API_KEY;delete process.env.AI_API_KEY;});
const context={members:[{id:1,name:'One'},{id:2,name:'Two'}],user:{id:1},currency:'MUR',today:'2026-09-24'};
const draft={description:'Dinner',amount:100,currency:'MUR',participants:[1,2],payer_id:1,expense_date:'2026-09-24',category:'Food',confidence:1,questions:[]};
function provider(result){process.env.GEMINI_API_KEY='test-only-key';globalThis.fetch=async(url,options)=>{assert.match(url,/generativelanguage.googleapis.com/);assert.equal(options.headers['x-goog-api-key'],'test-only-key');return new Response(JSON.stringify({candidates:[{content:{parts:[{text:JSON.stringify(result)}]}}]}),{status:200});};}
test('OCR selects labelled total, not tax, cash or subtotal',()=>{
 const r=receiptFromText('CAFE CENTRAL\n2026-09-24\nSubtotal 100.00\nVAT 15.00\nTOTAL Rs 115.00\nCash 200.00\nChange 85.00');
 assert.equal(r.amount,115);assert.equal(r.merchant,'CAFE CENTRAL');assert.equal(r.expense_date,'2026-09-24');
 assert.equal(receiptFromText('Shop\nTotal 12,50').amount,12.5);
 assert.equal(receiptFromText('Shop\nTotal 1,234.50').amount,1234.5);
});
test('OCR leaves ambiguous totals and dates blank rather than guessing',()=>{
 assert.equal(receiptFromText('Store\nTotal 100.00\nTotal 120.00').amount,null);
 assert.equal(receiptFromText('Store\nSubtotal 100.00\n2026-02-30').expense_date,null);
 assert.equal(receiptFromText('Store\n01/02/2026\nCash 50.00').amount,null);
});
test('Gemini expense response is validated against actual group members',async()=>{
 provider(draft);const r=await parseExpense('Dinner',context);assert.equal(r.mode,'Gemini AI');assert.equal(r.amount,100);
 provider({...draft,participants:[999]});await assert.rejects(()=>parseExpense('Dinner',context),/unknown member/);
});
test('Gemini conversation and transcription use real provider adapters',async()=>{
 provider({reply:'Please review this split.',draft});const r=await chatAssistant([{role:'user',content:'Split dinner'}],context);assert.equal(r.draft.amount,100);
 provider({text:'Dinner was one hundred rupees'});assert.equal((await transcribeAudio(Buffer.alloc(44))).text,'Dinner was one hundred rupees');
 provider({merchant:'Cafe',amount:100,expense_date:null,taxes:null,items:[]});assert.equal((await extractReceipt(Buffer.from('sample'),'image/png')).amount,100);
});
test('Gemini quota and key errors remain actionable without fabricated results',async()=>{
 process.env.GEMINI_API_KEY='test-only-key';globalThis.fetch=async()=>new Response('{}',{status:429});await assert.rejects(()=>parseExpense('Dinner',context),/quota/);
 globalThis.fetch=async()=>new Response('{}',{status:403});await assert.rejects(()=>parseExpense('Dinner',context),/API key/);
 globalThis.fetch=async()=>new Response('{}',{status:200});await assert.rejects(()=>parseExpense('Dinner',context),/usable answer/);
});

test('AI payment review flags mismatches and stays advisory even for matching details',async()=>{
 const {reviewProof}=await import('../services/payment-proof.js');
 const details={amount:12,currency:'MUR',recipient:'Recipient',reference:'REF1',date:'2026-09-24',status:'completed',concerns:[]};
 provider(details);
 const r=await reviewProof(Buffer.from('test'),'image/png',{amount:1200,currency:'MUR'},true);assert.equal(r.status,'details_read');assert.match(r.summary,/cannot establish authenticity/);assert.equal(r.settled,undefined);
 provider({...details,amount:100,status:'pending'});const mismatch=await reviewProof(Buffer.from('test'),'image/png',{amount:1200,currency:'MUR'},true);assert.equal(mismatch.status,'needs_review');assert(mismatch.flags.some(f=>f.includes('amount differs')));
 globalThis.fetch=async()=>{throw new Error('Must not send without consent');};assert.equal((await reviewProof(Buffer.from('test'),'image/png',{amount:1200,currency:'MUR'},false)).status,'manual_review');
 assert.equal((await reviewProof(Buffer.from('test'),'image/png',{amount:1200,currency:'MUR'},true)).status,'manual_review');
});
