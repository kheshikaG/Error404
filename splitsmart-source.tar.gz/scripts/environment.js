// Render supplies its assigned HTTPS URL; keep CSRF checks on that exact origin.
if(!process.env.APP_ORIGIN&&process.env.RENDER_EXTERNAL_URL){
 process.env.APP_ORIGIN=new URL(process.env.RENDER_EXTERNAL_URL).origin;
}
