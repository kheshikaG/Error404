import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
if (existsSync('.env')) { console.log('.env already exists; left unchanged.'); }
else {
  let text = readFileSync('.env.example','utf8');
  text = text.replace('SESSION_SECRET=', `SESSION_SECRET=${randomBytes(32).toString('hex')}`).replace('ENCRYPTION_KEY=', `ENCRYPTION_KEY=${randomBytes(32).toString('hex')}`);
  writeFileSync('.env',text,{mode:0o600});
  console.log('Created local .env with random secrets.');
}
