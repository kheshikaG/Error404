import {createRequire} from 'node:module';
import {mkdirSync,copyFileSync,readdirSync} from 'node:fs';
import {dirname,join} from 'node:path';
const require=createRequire(import.meta.url);
const out=new URL('../public/vendor/',import.meta.url);
mkdirSync(out,{recursive:true});
function copy(source,name){copyFileSync(source,new URL(name,out));}
const tess=dirname(require.resolve('tesseract.js/package.json'));
const core=dirname(createRequire(join(tess,'package.json')).resolve('tesseract.js-core/package.json'));
copy(join(tess,'dist/tesseract.min.js'),'tesseract.min.js');
copy(join(tess,'dist/worker.min.js'),'worker.min.js');
for(const file of readdirSync(core))if(/\.wasm(\.js)?$/.test(file))copy(join(core,file),file);
copy(join(dirname(require.resolve('@tesseract.js-data/eng/package.json')),'4.0.0/eng.traineddata.gz'),'eng.traineddata.gz');
const pdf=dirname(require.resolve('pdfjs-dist/package.json'));
copy(join(pdf,'build/pdf.min.mjs'),'pdf.min.mjs');
copy(join(pdf,'build/pdf.worker.min.mjs'),'pdf.worker.min.mjs');
copy(join(tess,'LICENSE.md'),'TESSERACT-LICENSE');
copy(join(pdf,'LICENSE'),'PDFJS-LICENSE');
console.log('Prepared self-hosted receipt OCR assets.');
